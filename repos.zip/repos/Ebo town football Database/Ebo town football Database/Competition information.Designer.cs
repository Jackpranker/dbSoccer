﻿using System;

namespace Ebo_town_football_Database
{
    partial class Competition_information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Competition_information));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.c_teamid = new System.Windows.Forms.TextBox();
            this.c_name = new System.Windows.Forms.TextBox();
            this.c_year = new System.Windows.Forms.TextBox();
            this.c_remarks = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.c_Save = new System.Windows.Forms.Button();
            this.c_delete = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.c_competitionid = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.t_search = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 162);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "TeamID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(53, 211);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Remarks";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(79, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Year";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(72, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Name";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // c_teamid
            // 
            this.c_teamid.Location = new System.Drawing.Point(121, 158);
            this.c_teamid.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.c_teamid.Name = "c_teamid";
            this.c_teamid.Size = new System.Drawing.Size(132, 22);
            this.c_teamid.TabIndex = 5;
            this.c_teamid.TextChanged += new System.EventHandler(this.c_teamid_TextChanged);
            // 
            // c_name
            // 
            this.c_name.Location = new System.Drawing.Point(121, 86);
            this.c_name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.c_name.Name = "c_name";
            this.c_name.Size = new System.Drawing.Size(132, 22);
            this.c_name.TabIndex = 6;
            this.c_name.TextChanged += new System.EventHandler(this.c_name_TextChanged);
            // 
            // c_year
            // 
            this.c_year.Location = new System.Drawing.Point(121, 122);
            this.c_year.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.c_year.Multiline = true;
            this.c_year.Name = "c_year";
            this.c_year.Size = new System.Drawing.Size(132, 22);
            this.c_year.TabIndex = 7;
            this.c_year.TextChanged += new System.EventHandler(this.c_year_TextChanged);
            // 
            // c_remarks
            // 
            this.c_remarks.Location = new System.Drawing.Point(122, 200);
            this.c_remarks.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.c_remarks.Multiline = true;
            this.c_remarks.Name = "c_remarks";
            this.c_remarks.Size = new System.Drawing.Size(132, 58);
            this.c_remarks.TabIndex = 9;
            this.c_remarks.TextChanged += new System.EventHandler(this.c_remarks_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Gray;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label6.Font = new System.Drawing.Font("Mary Jane Antique", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(12, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(278, 37);
            this.label6.TabIndex = 10;
            this.label6.Text = "COMPETITION INFO";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // c_Save
            // 
            this.c_Save.BackColor = System.Drawing.Color.Lime;
            this.c_Save.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.c_Save.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.c_Save.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.c_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.c_Save.Location = new System.Drawing.Point(157, 272);
            this.c_Save.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.c_Save.Name = "c_Save";
            this.c_Save.Size = new System.Drawing.Size(61, 32);
            this.c_Save.TabIndex = 11;
            this.c_Save.Text = "Save";
            this.c_Save.UseVisualStyleBackColor = false;
            this.c_Save.Click += new System.EventHandler(this.c_Save_Click);
            // 
            // c_delete
            // 
            this.c_delete.BackColor = System.Drawing.Color.Red;
            this.c_delete.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.c_delete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.c_delete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.c_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c_delete.ForeColor = System.Drawing.Color.White;
            this.c_delete.Location = new System.Drawing.Point(224, 272);
            this.c_delete.Name = "c_delete";
            this.c_delete.Size = new System.Drawing.Size(69, 34);
            this.c_delete.TabIndex = 13;
            this.c_delete.Text = "Delete";
            this.c_delete.UseVisualStyleBackColor = false;
            this.c_delete.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Blue;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MidnightBlue;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(85, 272);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(66, 33);
            this.button1.TabIndex = 14;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // c_competitionid
            // 
            this.c_competitionid.Location = new System.Drawing.Point(122, 51);
            this.c_competitionid.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.c_competitionid.Name = "c_competitionid";
            this.c_competitionid.Size = new System.Drawing.Size(132, 22);
            this.c_competitionid.TabIndex = 16;
            this.c_competitionid.TextChanged += new System.EventHandler(this.c_competitionid_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 15);
            this.label5.TabIndex = 15;
            this.label5.Text = "CompetitionID";
            // 
            // t_search
            // 
            this.t_search.BackColor = System.Drawing.Color.White;
            this.t_search.Font = new System.Drawing.Font("Josy Wine", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t_search.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.t_search.Location = new System.Drawing.Point(345, 272);
            this.t_search.Multiline = true;
            this.t_search.Name = "t_search";
            this.t_search.Size = new System.Drawing.Size(246, 23);
            this.t_search.TabIndex = 23;
            this.t_search.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.t_search.TextChanged += new System.EventHandler(this.t_search_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Gray;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView1.GridColor = System.Drawing.Color.Gray;
            this.dataGridView1.Location = new System.Drawing.Point(323, 20);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridView1.Size = new System.Drawing.Size(538, 246);
            this.dataGridView1.TabIndex = 21;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Lucida Fax", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(15, 272);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(64, 34);
            this.button2.TabIndex = 24;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(323, 272);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(46, 23);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 63;
            this.pictureBox1.TabStop = false;
            // 
            // Competition_information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(861, 350);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.t_search);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.c_competitionid);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.c_delete);
            this.Controls.Add(this.c_Save);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.c_remarks);
            this.Controls.Add(this.c_year);
            this.Controls.Add(this.c_name);
            this.Controls.Add(this.c_teamid);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Lucida Bright", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Competition_information";
            this.Opacity = 0.9D;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Competition Information";
            this.Load += new System.EventHandler(this.Competition_information_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void C_update_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox c_teamid;
        private System.Windows.Forms.TextBox c_name;
        private System.Windows.Forms.TextBox c_year;
        private System.Windows.Forms.TextBox c_remarks;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button c_Save;
        private System.Windows.Forms.Button c_delete;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox c_competitionid;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox t_search;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}