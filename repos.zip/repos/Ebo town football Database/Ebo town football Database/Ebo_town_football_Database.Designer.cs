﻿
namespace Ebo_town_football_Database
{
    partial class Ebo_town_football_Database
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Ebo_town_football_Database));
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.competitionInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.goalInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.matchInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.playerInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreeInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teamInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.venueInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.searchInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip.SuspendLayout();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolTip
            // 
            this.toolTip.Popup += new System.Windows.Forms.PopupEventHandler(this.toolTip_Popup);
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 20);
            this.toolStripDropDownButton1.Text = "toolStripDropDownButton1";
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1});
            this.statusStrip.Location = new System.Drawing.Point(0, 537);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Padding = new System.Windows.Forms.Padding(2, 0, 20, 0);
            this.statusStrip.Size = new System.Drawing.Size(1217, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // competitionInformationToolStripMenuItem
            // 
            this.competitionInformationToolStripMenuItem.Font = new System.Drawing.Font("Lucida Fax", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.competitionInformationToolStripMenuItem.Name = "competitionInformationToolStripMenuItem";
            this.competitionInformationToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.competitionInformationToolStripMenuItem.Text = "Competition Information";
            this.competitionInformationToolStripMenuItem.Click += new System.EventHandler(this.competitionInformationToolStripMenuItem_Click);
            // 
            // goalInformationToolStripMenuItem
            // 
            this.goalInformationToolStripMenuItem.Font = new System.Drawing.Font("Lucida Fax", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.goalInformationToolStripMenuItem.Name = "goalInformationToolStripMenuItem";
            this.goalInformationToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.goalInformationToolStripMenuItem.Text = "Goal Information";
            this.goalInformationToolStripMenuItem.Click += new System.EventHandler(this.goalInformationToolStripMenuItem_Click);
            // 
            // matchInformationToolStripMenuItem
            // 
            this.matchInformationToolStripMenuItem.Font = new System.Drawing.Font("Lucida Fax", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.matchInformationToolStripMenuItem.Name = "matchInformationToolStripMenuItem";
            this.matchInformationToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.matchInformationToolStripMenuItem.Text = "Match Information";
            this.matchInformationToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.matchInformationToolStripMenuItem.Click += new System.EventHandler(this.matchInformationToolStripMenuItem_Click);
            // 
            // playerInformationToolStripMenuItem
            // 
            this.playerInformationToolStripMenuItem.Font = new System.Drawing.Font("Lucida Fax", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playerInformationToolStripMenuItem.Name = "playerInformationToolStripMenuItem";
            this.playerInformationToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.playerInformationToolStripMenuItem.Text = "Player Information";
            this.playerInformationToolStripMenuItem.Click += new System.EventHandler(this.playerInformationToolStripMenuItem_Click);
            // 
            // refreeInformationToolStripMenuItem
            // 
            this.refreeInformationToolStripMenuItem.Font = new System.Drawing.Font("Lucida Fax", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refreeInformationToolStripMenuItem.Name = "refreeInformationToolStripMenuItem";
            this.refreeInformationToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.refreeInformationToolStripMenuItem.Text = "Refree Information";
            this.refreeInformationToolStripMenuItem.Click += new System.EventHandler(this.refreeInformationToolStripMenuItem_Click);
            // 
            // teamInformationToolStripMenuItem
            // 
            this.teamInformationToolStripMenuItem.Font = new System.Drawing.Font("Lucida Fax", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teamInformationToolStripMenuItem.Name = "teamInformationToolStripMenuItem";
            this.teamInformationToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.teamInformationToolStripMenuItem.Text = "Team Information";
            this.teamInformationToolStripMenuItem.Click += new System.EventHandler(this.teamInformationToolStripMenuItem_Click);
            // 
            // venueInformationToolStripMenuItem
            // 
            this.venueInformationToolStripMenuItem.Font = new System.Drawing.Font("Lucida Fax", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.venueInformationToolStripMenuItem.Name = "venueInformationToolStripMenuItem";
            this.venueInformationToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.venueInformationToolStripMenuItem.Text = "Venue Information";
            this.venueInformationToolStripMenuItem.Click += new System.EventHandler(this.venueInformationToolStripMenuItem_Click);
            // 
            // menuStrip
            // 
            this.menuStrip.BackColor = System.Drawing.Color.Gray;
            this.menuStrip.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Document);
            this.menuStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.competitionInformationToolStripMenuItem,
            this.goalInformationToolStripMenuItem,
            this.matchInformationToolStripMenuItem,
            this.playerInformationToolStripMenuItem,
            this.refreeInformationToolStripMenuItem,
            this.teamInformationToolStripMenuItem,
            this.venueInformationToolStripMenuItem,
            this.searchInformationToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(9, 1, 0, 1);
            this.menuStrip.Size = new System.Drawing.Size(1217, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            this.menuStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip_ItemClicked);
            // 
            // searchInformationToolStripMenuItem
            // 
            this.searchInformationToolStripMenuItem.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchInformationToolStripMenuItem.Name = "searchInformationToolStripMenuItem";
            this.searchInformationToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.searchInformationToolStripMenuItem.Text = "Search Information";
            this.searchInformationToolStripMenuItem.Click += new System.EventHandler(this.searchInformationToolStripMenuItem_Click);
            // 
            // Ebo_town_football_Database
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.Silver;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1217, 559);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MinimizeBox = false;
            this.Name = "Ebo_town_football_Database";
            this.Opacity = 0.97D;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ebo_town football Database";
            this.Load += new System.EventHandler(this.Ebo_town_football_Database_Load);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripMenuItem competitionInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem goalInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem matchInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem playerInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreeInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teamInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem venueInformationToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem searchInformationToolStripMenuItem;
    }
}



