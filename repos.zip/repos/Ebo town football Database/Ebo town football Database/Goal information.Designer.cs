﻿namespace Ebo_town_football_Database
{
    partial class Goal_information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Goal_information));
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.g_teamid = new System.Windows.Forms.TextBox();
            this.g_scorer = new System.Windows.Forms.TextBox();
            this.g_goalTime = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.g_Comment = new System.Windows.Forms.TextBox();
            this.Comment = new System.Windows.Forms.Label();
            this.g_Save = new System.Windows.Forms.Button();
            this.g_delete = new System.Windows.Forms.Button();
            this.g_update = new System.Windows.Forms.Button();
            this.g_goalid = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.t_search = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(59, 99);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "TeamID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(64, 134);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Scorer";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(44, 178);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Goal_time";
            // 
            // g_teamid
            // 
            this.g_teamid.Location = new System.Drawing.Point(124, 96);
            this.g_teamid.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.g_teamid.Name = "g_teamid";
            this.g_teamid.Size = new System.Drawing.Size(139, 22);
            this.g_teamid.TabIndex = 6;
            // 
            // g_scorer
            // 
            this.g_scorer.Location = new System.Drawing.Point(124, 134);
            this.g_scorer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.g_scorer.Name = "g_scorer";
            this.g_scorer.Size = new System.Drawing.Size(139, 22);
            this.g_scorer.TabIndex = 7;
            this.g_scorer.TextChanged += new System.EventHandler(this.g_scorer_TextChanged);
            // 
            // g_goalTime
            // 
            this.g_goalTime.Location = new System.Drawing.Point(124, 178);
            this.g_goalTime.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.g_goalTime.Name = "g_goalTime";
            this.g_goalTime.Size = new System.Drawing.Size(139, 22);
            this.g_goalTime.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Gray;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label6.Font = new System.Drawing.Font("Mary Jane Antique", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(62, 12);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(201, 41);
            this.label6.TabIndex = 10;
            this.label6.Text = "GOAL INFO";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // g_Comment
            // 
            this.g_Comment.Location = new System.Drawing.Point(124, 220);
            this.g_Comment.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.g_Comment.Name = "g_Comment";
            this.g_Comment.Size = new System.Drawing.Size(139, 22);
            this.g_Comment.TabIndex = 12;
            this.g_Comment.TextChanged += new System.EventHandler(this.g_Comment_TextChanged);
            // 
            // Comment
            // 
            this.Comment.AutoSize = true;
            this.Comment.Location = new System.Drawing.Point(44, 220);
            this.Comment.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Comment.Name = "Comment";
            this.Comment.Size = new System.Drawing.Size(71, 15);
            this.Comment.TabIndex = 11;
            this.Comment.Text = "Comment";
            // 
            // g_Save
            // 
            this.g_Save.BackColor = System.Drawing.Color.Lime;
            this.g_Save.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.g_Save.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.g_Save.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.g_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.g_Save.Location = new System.Drawing.Point(163, 264);
            this.g_Save.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.g_Save.Name = "g_Save";
            this.g_Save.Size = new System.Drawing.Size(64, 30);
            this.g_Save.TabIndex = 13;
            this.g_Save.Text = "Save";
            this.g_Save.UseVisualStyleBackColor = false;
            this.g_Save.Click += new System.EventHandler(this.g_Save_Click);
            // 
            // g_delete
            // 
            this.g_delete.BackColor = System.Drawing.Color.Red;
            this.g_delete.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.g_delete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.g_delete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.g_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g_delete.ForeColor = System.Drawing.Color.White;
            this.g_delete.Location = new System.Drawing.Point(233, 264);
            this.g_delete.Name = "g_delete";
            this.g_delete.Size = new System.Drawing.Size(59, 30);
            this.g_delete.TabIndex = 15;
            this.g_delete.Text = "Delete";
            this.g_delete.UseVisualStyleBackColor = false;
            this.g_delete.Click += new System.EventHandler(this.g_delete_Click);
            // 
            // g_update
            // 
            this.g_update.BackColor = System.Drawing.Color.Blue;
            this.g_update.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.g_update.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.g_update.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.g_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g_update.ForeColor = System.Drawing.Color.White;
            this.g_update.Location = new System.Drawing.Point(92, 264);
            this.g_update.Name = "g_update";
            this.g_update.Size = new System.Drawing.Size(65, 30);
            this.g_update.TabIndex = 14;
            this.g_update.Text = "Update";
            this.g_update.UseVisualStyleBackColor = false;
            this.g_update.Click += new System.EventHandler(this.g_update_Click);
            // 
            // g_goalid
            // 
            this.g_goalid.Location = new System.Drawing.Point(124, 58);
            this.g_goalid.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.g_goalid.Name = "g_goalid";
            this.g_goalid.Size = new System.Drawing.Size(139, 22);
            this.g_goalid.TabIndex = 17;
            this.g_goalid.TextChanged += new System.EventHandler(this.g_goalid_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 61);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 15);
            this.label1.TabIndex = 16;
            this.label1.Text = "GoalID";
            // 
            // t_search
            // 
            this.t_search.BackColor = System.Drawing.Color.White;
            this.t_search.Font = new System.Drawing.Font("Josy Wine", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t_search.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.t_search.Location = new System.Drawing.Point(315, 272);
            this.t_search.Name = "t_search";
            this.t_search.Size = new System.Drawing.Size(278, 22);
            this.t_search.TabIndex = 26;
            this.t_search.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.t_search.TextChanged += new System.EventHandler(this.t_search_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Gray;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView1.GridColor = System.Drawing.Color.Gray;
            this.dataGridView1.Location = new System.Drawing.Point(315, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridView1.Size = new System.Drawing.Size(598, 252);
            this.dataGridView1.TabIndex = 24;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Lucida Fax", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(31, 264);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(55, 30);
            this.button2.TabIndex = 27;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(315, 272);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(46, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 63;
            this.pictureBox1.TabStop = false;
            // 
            // Goal_information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(933, 337);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.t_search);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.g_goalid);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.g_delete);
            this.Controls.Add(this.g_update);
            this.Controls.Add(this.g_Save);
            this.Controls.Add(this.g_Comment);
            this.Controls.Add(this.Comment);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.g_goalTime);
            this.Controls.Add(this.g_scorer);
            this.Controls.Add(this.g_teamid);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Lucida Bright", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Goal_information";
            this.Opacity = 0.9D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Goal Information";
            this.Load += new System.EventHandler(this.Goal_information_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox g_teamid;
        private System.Windows.Forms.TextBox g_scorer;
        private System.Windows.Forms.TextBox g_goalTime;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox g_Comment;
        private System.Windows.Forms.Label Comment;
        private System.Windows.Forms.Button g_Save;
        private System.Windows.Forms.Button g_delete;
        private System.Windows.Forms.Button g_update;
        private System.Windows.Forms.TextBox g_goalid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox t_search;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}