﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ebo_town_football_Database
{
    public partial class Goal_information : Form
    {
        SqlDataAdapter adapt;
        DataTable dt;
        public Goal_information()
        {
            InitializeComponent();
        }

        private void g_scorer_TextChanged(object sender, EventArgs e)
        {

        }

        private void g_Comment_TextChanged(object sender, EventArgs e)
        {

        }

        private void g_Save_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into Goal_Information(GoalID,TeamID,Scorer,Goal_Time,Comment) values" +
                    "('" + g_goalid.Text + "','" + g_teamid.Text + "','" + g_scorer.Text + "'," +
                    "'" + g_goalTime.Text + "','" + g_Comment.Text + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully saved record for Goal_Information  " + " Scorer " + g_scorer.Text);
                conn.Close();
              
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " + ex.Message);
            }
        }

        private void g_update_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "update Goal_Information set GoalID ='" + g_goalid.Text + "', TeamID='" + g_teamid.Text + "',Scorer='" + g_scorer.Text + "',Goal_Time='" + g_goalTime.Text + "',Comment='" + g_Comment.Text + "' where GoalID='" + g_goalid.Text + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully Updates record for Goal_Information  " + " GoalID " + g_goalid.Text);
                conn.Close();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Updates check it might exist " + ex.Message);
            }
        }

        private void g_delete_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "delete from Goal_Information where GoalID ='" + g_goalid.Text + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully delete record for Goal_Information  " + "GoalID " + g_goalid.Text);
                conn.Close();
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be delete check it might exist " + ex.Message);
            }
        }

        private void Goal_information_Load(object sender, EventArgs e)
        {
            try
            {

                string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
                SqlConnection conn = new SqlConnection();
                conn = new SqlConnection(cs);
                conn.Open();
                //put the name of the table
                adapt = new SqlDataAdapter("select * from Goal_Information", conn);
                dt = new DataTable();
                adapt.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Data view" + ex.Message);
                //conn.Close();

            }
        }

        private void t_search_TextChanged(object sender, EventArgs e)
        {
            string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection(cs);
            conn = new SqlConnection(cs);
            conn.Open();
            adapt = new SqlDataAdapter("select * from Goal_Information where GoalID like '" + t_search.Text + "%'", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
          

        }

        private void g_goalid_TextChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source = JP\\SQLEXPRESS; Initial Catalog = Ebo_town_football_database; Integrated Security = True");
            conn.Open();
            if (g_goalid.Text != "")
            {
                SqlCommand cmd = new SqlCommand("Select TeamID, Scorer,Goal_Time,Comment from Goal_Information where GoalID= @GoalID", conn);
                cmd.Parameters.AddWithValue("@GoalID", int.Parse(g_goalid.Text));
                SqlDataReader da = cmd.ExecuteReader();
                while (da.Read())
                {
                    g_teamid.Text = da.GetValue(0).ToString();
                    g_scorer.Text = da.GetValue(1).ToString();
                    g_goalTime.Text = da.GetValue(2).ToString();
                    g_Comment.Text = da.GetValue(3).ToString();


                }
                conn.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();



                MessageBox.Show(" Successfully cleared record for Competition_Information  ");
                conn.Close();
                g_goalid.Text = "";
                g_teamid.Text = "";
                g_scorer.Text = "";
                g_goalTime.Text = "";
                g_Comment.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " + ex.Message);
            }
        }
    }
}
    
    

