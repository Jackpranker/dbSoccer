﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ebo_town_football_Database
{
    public partial class Match_information : Form
    {
        SqlDataAdapter adapt;
        DataTable dt;
        public Match_information()
        {
            InitializeComponent();
        }

        private void Match_information_Load(object sender, EventArgs e)
        {
            try
            {

                string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
                SqlConnection conn = new SqlConnection();
                conn = new SqlConnection(cs);
                conn.Open();
                //put the name of the table
                adapt = new SqlDataAdapter("select * from Match_Information", conn);
                dt = new DataTable();
                adapt.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Data view" + ex.Message);
                //conn.Close();

            }
        }

        private void m_Save_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into Match_Information(MatchID,TeamID,GoalID,CompetitionID,Winner,Kick_off_Time,RefreeID,Home_vs_away,VenueID,Match_Statistics,Date,Remarks) " +
                    "values('" + m_matchid.Text + "','" + m_teamid.Text + "','" + m_goalid.Text + "','" +m_competitionid.Text + "','" + m_winner.Text + "','" + m_kick.Text + "'," +
                    "'" + m_refreeid.Text + "','" + m_Home_vs_away.Text + "','" + m_venueid.Text + "','" + m_matchStatistic.Text + "','" + m_date.Text + "','" + m_remarks.Text + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully saved record for Match_Information  "  + " Winner " + m_winner.Text);
                conn.Close();
              
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " + ex.Message);
            }
        }

        private void m_update_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "update Match_Information set MatchID ='" + m_matchid.Text + "'," +
                    " TeamID='" + m_matchid.Text + "',GoalID='" + m_goalid.Text + "',CompetitionID='" + m_competitionid.Text + "'," +
                    "Winner='" +m_winner.Text + "' ,Kick_off_Time ='" + m_kick.Text + "', RefreeID ='" + m_refreeid.Text + "'" +
                    ",Home_vs_away ='" + m_Home_vs_away.Text + "',VenueID ='" + m_venueid.Text + "', " +
                    "Match_Statistics ='" + m_matchStatistic.Text + "',Date ='" + m_date.Text + "', Remarks ='" + m_remarks.Text + "'" +
                    " where MatchID='" + m_matchid.Text + "'";
                cmd.CommandType = CommandType.Text; 
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully Updates record for Match_Information  " + " MatchID " + m_matchid.Text);
                conn.Close();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Updates check it might exist " + ex.Message);
            }
        }

        private void m_delete_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "delete  from Match_Information where  MatchID = '" + m_matchid.Text + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully delete record for Competition_Information  " + "MatchID" + m_matchid.Text);
                conn.Close();
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be delete check it might exist " + ex.Message);
            }
        }

        private void t_search_TextChanged(object sender, EventArgs e)
        {
            string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection(cs);
            conn = new SqlConnection(cs);
            conn.Open();
            adapt = new SqlDataAdapter("select * from Match_Information where MatchID like '" + t_search.Text + "%'", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
         
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void m_matchid_TextChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source = JP\\SQLEXPRESS; Initial Catalog = Ebo_town_football_database; Integrated Security = True");
            conn.Open();
            if (m_matchid.Text != "")
            {
                SqlCommand cmd = new SqlCommand("Select TeamID, GoalID,CompetitionID,Winner,Kick_off_Time,RefreeID,Home_vs_Away,VenueID,Match_Statistics,Date,Remarks from Match_Information where MatchID= @MatchID", conn);
                cmd.Parameters.AddWithValue("@MatchID", int.Parse(m_matchid.Text));
                SqlDataReader da = cmd.ExecuteReader();
                while (da.Read())
                {
                    m_teamid.Text = da.GetValue(0).ToString();
                    m_goalid.Text = da.GetValue(1).ToString();
                    m_competitionid.Text = da.GetValue(2).ToString();
                    m_winner.Text = da.GetValue(3).ToString();
                    m_kick.Text = da.GetValue(4).ToString();
                    m_refreeid.Text = da.GetValue(5).ToString();
                    m_Home_vs_away.Text = da.GetValue(6).ToString();
                    m_venueid.Text = da.GetValue(7).ToString();
                    m_matchStatistic.Text = da.GetValue(8).ToString();
                    m_date.Text = da.GetValue(9).ToString();
                    m_remarks.Text = da.GetValue(10).ToString();
                
                }
                conn.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();



                MessageBox.Show(" Successfully cleared record for Competition_Information  ");
                conn.Close();
                m_matchid.Text = "";
                m_teamid.Text = "";
                m_goalid.Text = "";
                m_competitionid.Text = "";
                m_winner.Text = "";
                m_kick.Text = "";
                m_refreeid.Text = "";
                m_Home_vs_away.Text = "";
                m_venueid.Text = "";
                m_matchStatistic.Text = "";
                m_date.Text = "";
                m_remarks.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " + ex.Message);
            }
        }
    }
    }
    
    

