﻿namespace Ebo_town_football_Database
{
    partial class Player_information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Player_information));
            this.p_teamid = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.p_nationality = new System.Windows.Forms.TextBox();
            this.p_height = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.p_position = new System.Windows.Forms.TextBox();
            this.p_male = new System.Windows.Forms.RadioButton();
            this.p_female = new System.Windows.Forms.RadioButton();
            this.p_contact = new System.Windows.Forms.TextBox();
            this.p_address = new System.Windows.Forms.TextBox();
            this.p_dob = new System.Windows.Forms.DateTimePicker();
            this.p_lastName = new System.Windows.Forms.TextBox();
            this.p_firstName = new System.Windows.Forms.TextBox();
            this.p_image = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.p_Save = new System.Windows.Forms.Button();
            this.p_delte = new System.Windows.Forms.Button();
            this.p_update = new System.Windows.Forms.Button();
            this.p_playerid = new System.Windows.Forms.TextBox();
            this.p_playeridddd = new System.Windows.Forms.Label();
            this.t_search = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.image = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.p_image)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // p_teamid
            // 
            this.p_teamid.BackColor = System.Drawing.SystemColors.MenuBar;
            this.p_teamid.Location = new System.Drawing.Point(364, 341);
            this.p_teamid.Name = "p_teamid";
            this.p_teamid.Size = new System.Drawing.Size(144, 23);
            this.p_teamid.TabIndex = 49;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(290, 344);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 15);
            this.label12.TabIndex = 48;
            this.label12.Text = "TeamID";
            // 
            // p_nationality
            // 
            this.p_nationality.BackColor = System.Drawing.SystemColors.MenuBar;
            this.p_nationality.Location = new System.Drawing.Point(364, 300);
            this.p_nationality.Multiline = true;
            this.p_nationality.Name = "p_nationality";
            this.p_nationality.Size = new System.Drawing.Size(144, 25);
            this.p_nationality.TabIndex = 47;
            // 
            // p_height
            // 
            this.p_height.BackColor = System.Drawing.SystemColors.HighlightText;
            this.p_height.Location = new System.Drawing.Point(71, 389);
            this.p_height.Multiline = true;
            this.p_height.Name = "p_height";
            this.p_height.Size = new System.Drawing.Size(71, 20);
            this.p_height.TabIndex = 46;
            this.p_height.Text = "        cm";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(277, 303);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 15);
            this.label10.TabIndex = 34;
            this.label10.Text = "Nationality";
            // 
            // p_position
            // 
            this.p_position.BackColor = System.Drawing.SystemColors.HighlightText;
            this.p_position.Location = new System.Drawing.Point(166, 389);
            this.p_position.Multiline = true;
            this.p_position.Name = "p_position";
            this.p_position.Size = new System.Drawing.Size(97, 21);
            this.p_position.TabIndex = 45;
            // 
            // p_male
            // 
            this.p_male.AutoSize = true;
            this.p_male.Font = new System.Drawing.Font("Lucida Bright", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_male.Location = new System.Drawing.Point(446, 268);
            this.p_male.Name = "p_male";
            this.p_male.Size = new System.Drawing.Size(46, 17);
            this.p_male.TabIndex = 44;
            this.p_male.TabStop = true;
            this.p_male.Text = "Male";
            this.p_male.UseVisualStyleBackColor = true;
            this.p_male.CheckedChanged += new System.EventHandler(this.p_male_CheckedChanged);
            // 
            // p_female
            // 
            this.p_female.AutoSize = true;
            this.p_female.Font = new System.Drawing.Font("Lucida Bright", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_female.Location = new System.Drawing.Point(373, 268);
            this.p_female.Name = "p_female";
            this.p_female.Size = new System.Drawing.Size(57, 17);
            this.p_female.TabIndex = 43;
            this.p_female.TabStop = true;
            this.p_female.Text = "Female";
            this.p_female.UseVisualStyleBackColor = true;
            this.p_female.CheckedChanged += new System.EventHandler(this.p_female_CheckedChanged);
            // 
            // p_contact
            // 
            this.p_contact.BackColor = System.Drawing.SystemColors.MenuBar;
            this.p_contact.Location = new System.Drawing.Point(365, 237);
            this.p_contact.Name = "p_contact";
            this.p_contact.Size = new System.Drawing.Size(143, 23);
            this.p_contact.TabIndex = 42;
            this.p_contact.Text = "+220 ";
            // 
            // p_address
            // 
            this.p_address.BackColor = System.Drawing.SystemColors.Menu;
            this.p_address.Location = new System.Drawing.Point(365, 200);
            this.p_address.Name = "p_address";
            this.p_address.Size = new System.Drawing.Size(143, 23);
            this.p_address.TabIndex = 41;
            // 
            // p_dob
            // 
            this.p_dob.CalendarTitleForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.p_dob.CalendarTrailingForeColor = System.Drawing.SystemColors.Desktop;
            this.p_dob.CustomFormat = "yyyy-MM-dd";
            this.p_dob.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.p_dob.Location = new System.Drawing.Point(365, 164);
            this.p_dob.Name = "p_dob";
            this.p_dob.Size = new System.Drawing.Size(143, 23);
            this.p_dob.TabIndex = 40;
            // 
            // p_lastName
            // 
            this.p_lastName.BackColor = System.Drawing.SystemColors.MenuBar;
            this.p_lastName.Location = new System.Drawing.Point(366, 126);
            this.p_lastName.Multiline = true;
            this.p_lastName.Name = "p_lastName";
            this.p_lastName.Size = new System.Drawing.Size(142, 25);
            this.p_lastName.TabIndex = 39;
            // 
            // p_firstName
            // 
            this.p_firstName.BackColor = System.Drawing.SystemColors.MenuBar;
            this.p_firstName.Location = new System.Drawing.Point(366, 84);
            this.p_firstName.Multiline = true;
            this.p_firstName.Name = "p_firstName";
            this.p_firstName.Size = new System.Drawing.Size(142, 25);
            this.p_firstName.TabIndex = 38;
            // 
            // p_image
            // 
            this.p_image.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.p_image.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.p_image.Location = new System.Drawing.Point(69, 96);
            this.p_image.Name = "p_image";
            this.p_image.Size = new System.Drawing.Size(194, 268);
            this.p_image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p_image.TabIndex = 36;
            this.p_image.TabStop = false;
            this.p_image.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(286, 236);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(62, 15);
            this.label11.TabIndex = 35;
            this.label11.Text = "Contact";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(81, 371);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 15);
            this.label9.TabIndex = 33;
            this.label9.Text = "Height";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(180, 369);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 15);
            this.label8.TabIndex = 32;
            this.label8.Text = "Position";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(288, 200);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 15);
            this.label7.TabIndex = 31;
            this.label7.Text = "Address";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(266, 163);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 15);
            this.label5.TabIndex = 29;
            this.label5.Text = "Date_of_Birth";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(270, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 15);
            this.label4.TabIndex = 28;
            this.label4.Text = "First Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(270, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 15);
            this.label3.TabIndex = 27;
            this.label3.Text = "Last_Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(296, 265);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 15);
            this.label2.TabIndex = 26;
            this.label2.Text = "Gender";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.DodgerBlue;
            this.richTextBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.richTextBox1.Location = new System.Drawing.Point(25, 12);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(511, 40);
            this.richTextBox1.TabIndex = 50;
            this.richTextBox1.Text = "";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.DodgerBlue;
            this.label13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label13.Font = new System.Drawing.Font("Modern No. 20", 18.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(69, 21);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(459, 26);
            this.label13.TabIndex = 51;
            this.label13.Text = "ENTER PLAYER PROFILE DETAILS";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // p_Save
            // 
            this.p_Save.BackColor = System.Drawing.Color.Lime;
            this.p_Save.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.p_Save.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.p_Save.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.p_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.p_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.p_Save.Location = new System.Drawing.Point(418, 389);
            this.p_Save.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.p_Save.Name = "p_Save";
            this.p_Save.Size = new System.Drawing.Size(61, 33);
            this.p_Save.TabIndex = 52;
            this.p_Save.Text = "Save";
            this.p_Save.UseVisualStyleBackColor = false;
            this.p_Save.Click += new System.EventHandler(this.p_Save_Click);
            // 
            // p_delte
            // 
            this.p_delte.BackColor = System.Drawing.Color.Red;
            this.p_delte.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.p_delte.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.p_delte.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.p_delte.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.p_delte.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_delte.ForeColor = System.Drawing.Color.White;
            this.p_delte.Location = new System.Drawing.Point(485, 389);
            this.p_delte.Name = "p_delte";
            this.p_delte.Size = new System.Drawing.Size(64, 33);
            this.p_delte.TabIndex = 54;
            this.p_delte.Text = "Delete";
            this.p_delte.UseVisualStyleBackColor = false;
            this.p_delte.Click += new System.EventHandler(this.p_delte_Click);
            // 
            // p_update
            // 
            this.p_update.BackColor = System.Drawing.Color.Blue;
            this.p_update.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.p_update.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.p_update.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.p_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.p_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_update.ForeColor = System.Drawing.Color.White;
            this.p_update.Location = new System.Drawing.Point(344, 389);
            this.p_update.Name = "p_update";
            this.p_update.Size = new System.Drawing.Size(68, 33);
            this.p_update.TabIndex = 53;
            this.p_update.Text = "Update";
            this.p_update.UseVisualStyleBackColor = false;
            this.p_update.Click += new System.EventHandler(this.p_update_Click);
            // 
            // p_playerid
            // 
            this.p_playerid.BackColor = System.Drawing.SystemColors.MenuBar;
            this.p_playerid.Location = new System.Drawing.Point(184, 68);
            this.p_playerid.Multiline = true;
            this.p_playerid.Name = "p_playerid";
            this.p_playerid.Size = new System.Drawing.Size(79, 22);
            this.p_playerid.TabIndex = 56;
            this.p_playerid.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // p_playeridddd
            // 
            this.p_playeridddd.AutoSize = true;
            this.p_playeridddd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.p_playeridddd.Location = new System.Drawing.Point(116, 71);
            this.p_playeridddd.Name = "p_playeridddd";
            this.p_playeridddd.Size = new System.Drawing.Size(62, 15);
            this.p_playeridddd.TabIndex = 55;
            this.p_playeridddd.Text = "PlayerID";
            // 
            // t_search
            // 
            this.t_search.BackColor = System.Drawing.Color.White;
            this.t_search.Font = new System.Drawing.Font("Josy Wine", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t_search.ForeColor = System.Drawing.SystemColors.Window;
            this.t_search.Location = new System.Drawing.Point(595, 371);
            this.t_search.Name = "t_search";
            this.t_search.Size = new System.Drawing.Size(274, 22);
            this.t_search.TabIndex = 59;
            this.t_search.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.t_search.TextChanged += new System.EventHandler(this.t_search_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.NullValue = null;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightGray;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView1.GridColor = System.Drawing.Color.Gainsboro;
            this.dataGridView1.Location = new System.Drawing.Point(531, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.Size = new System.Drawing.Size(841, 352);
            this.dataGridView1.TabIndex = 57;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dataGridView1_DataError);
            // 
            // image
            // 
            this.image.BackColor = System.Drawing.Color.Transparent;
            this.image.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.image.FlatAppearance.BorderSize = 2;
            this.image.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.image.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.image.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.image.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.image.Location = new System.Drawing.Point(130, 333);
            this.image.Name = "image";
            this.image.Size = new System.Drawing.Size(81, 26);
            this.image.TabIndex = 60;
            this.image.Text = "Image";
            this.image.UseVisualStyleBackColor = false;
            this.image.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Lucida Fax", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(280, 389);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(58, 32);
            this.button2.TabIndex = 61;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(595, 371);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(46, 23);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 62;
            this.pictureBox1.TabStop = false;
            // 
            // Player_information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1370, 465);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.image);
            this.Controls.Add(this.t_search);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.p_playerid);
            this.Controls.Add(this.p_playeridddd);
            this.Controls.Add(this.p_delte);
            this.Controls.Add(this.p_update);
            this.Controls.Add(this.p_Save);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.p_teamid);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.p_nationality);
            this.Controls.Add(this.p_height);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.p_position);
            this.Controls.Add(this.p_male);
            this.Controls.Add(this.p_female);
            this.Controls.Add(this.p_contact);
            this.Controls.Add(this.p_address);
            this.Controls.Add(this.p_dob);
            this.Controls.Add(this.p_lastName);
            this.Controls.Add(this.p_firstName);
            this.Controls.Add(this.p_image);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Player_information";
            this.Opacity = 0.9D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Player Information";
            this.Load += new System.EventHandler(this.Player_information_Load);
            ((System.ComponentModel.ISupportInitialize)(this.p_image)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox p_teamid;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox p_nationality;
        private System.Windows.Forms.TextBox p_height;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox p_position;
        private System.Windows.Forms.RadioButton p_male;
        private System.Windows.Forms.RadioButton p_female;
        private System.Windows.Forms.TextBox p_contact;
        private System.Windows.Forms.TextBox p_address;
        private System.Windows.Forms.DateTimePicker p_dob;
        private System.Windows.Forms.TextBox p_lastName;
        private System.Windows.Forms.TextBox p_firstName;
        private System.Windows.Forms.PictureBox p_image;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button p_Save;
        private System.Windows.Forms.Button p_delte;
        private System.Windows.Forms.Button p_update;
        private System.Windows.Forms.TextBox p_playerid;
        private System.Windows.Forms.Label p_playeridddd;
        private System.Windows.Forms.TextBox t_search;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button image;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}