﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Ebo_town_football_Database
{
    public partial class Player_information : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True");
        SqlCommand Command;
        string imgLoc = "";


        SqlDataAdapter adapt;
        DataTable dt;
        string Gender;
        public Player_information()
        {
            InitializeComponent();
        }

        private void Player_information_Load(object sender, EventArgs e)
        {
            try
            {

                string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
                SqlConnection conn = new SqlConnection();
                conn = new SqlConnection(cs);
                conn.Open();
                //put the name of the table
                adapt = new SqlDataAdapter("select * from Player_Information", conn);
                dt = new DataTable();
                adapt.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Data view" + ex.Message);
                //conn.Close();

            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void p_Save_Click(object sender, EventArgs e)
        {
            try
            {
               


                byte[] img = null;
                FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                img = br.ReadBytes((int)fs.Length);
                string sql = "insert into Player_Information(PlayerID,First_Name,Last_Name,Date_of_Birth,Address,Contact,Gender,Nationality,TeamID,Position,Height,Photo) " +
                   "values('" + p_playerid.Text + "','" + p_firstName.Text + "','" + p_lastName.Text + "','" + p_dob.Text + "','" + p_address.Text + "','" + p_contact.Text + "'," +
                   "'" + Gender + "','" + p_nationality.Text + "','" + p_teamid.Text + "','" + p_position.Text + "','" + p_height.Text + "',@img)";
                if (conn.State != ConnectionState.Open)
                    conn.Open();
                Command = new SqlCommand(sql, conn);
                Command.Parameters.Add(new SqlParameter("@img", img));
                int x = Command.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show( "Successfully Saved record for Player_Information  " + "PlayerID " + p_playerid.Text+" First_Name "+p_firstName.Text);
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show(ex.Message);
            }
        }

        

        private void p_female_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "Female";
        }

        private void p_male_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "male";
        }

        private void p_update_Click(object sender, EventArgs e)
        {

            try
            {
                byte[] img = null;
                FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                img = br.ReadBytes((int)fs.Length);
                String sql = "update Player_Information set PlayerID ='" + p_playerid.Text + "',First_Name='" + p_firstName.Text + "'" +
                    ",Last_Name='" + p_lastName.Text + "',Date_of_Birth='" + p_dob.Text + "'," +
                    "Address='" + p_address.Text + "' ,Contact ='" + p_contact.Text + "' ,Gender='"+Gender+"' ,Nationality ='" + p_nationality.Text + "'," +
                    "TeamID ='" + p_teamid.Text + "', Position ='" + p_position.Text + "'," +
                    "Height ='" + p_height.Text + "'  , Photo= @img "+
                    "where PlayerID='" + p_playerid.Text + "'";
                if (conn.State != ConnectionState.Open)
                    conn.Open();
                Command = new SqlCommand(sql, conn);
                Command.Parameters.Add(new SqlParameter("@img", img));
                Command.ExecuteNonQuery();
                int x = Command.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show( "Successfully updates record for Player_Information  " + "PlayerID " + p_playerid.Text + " First_Name " + p_firstName.Text);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Updates check it might exist " + ex.Message);
            }
        }

        private void p_delte_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "delete  from Player_Information where  PlayerID = '" + p_playerid.Text + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully delete record for Player_Information  " + "PlayerID" + p_playerid.Text);
                conn.Close();
              
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be delete check it might exist " + ex.Message);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {


                string sql = "Select First_Name, Last_Name,Date_of_birth,Address,Contact,Gender,Nationality,TeamID,Position,Height,Photo from Player_Information where PlayerID='"+ p_playerid.Text + "' ";
                if (conn.State != ConnectionState.Open)
                    conn.Open();
                Command = new SqlCommand(sql, conn);
                SqlDataReader reader = Command.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    p_firstName.Text = reader[0].ToString();
                    p_lastName.Text = reader[1].ToString();
                    p_dob.Text = reader[2].ToString();
                    p_address.Text = reader[3].ToString();
                    p_contact.Text = reader[4].ToString();
                    Gender = reader[5].ToString();
                    p_nationality.Text = reader[6].ToString();
                    p_teamid.Text = reader[7].ToString();
                    p_position.Text = reader[8].ToString();
                    p_height.Text = reader[9].ToString();
                    byte[] img = (byte[])(reader[10]);
                
                    if (img == null)
                        p_image.Image = null;
                    else
                    {
                        MemoryStream ms = new MemoryStream(img);
                        p_image.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    //MessageBox.Show("The image doesnot exits");
                }
                conn.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            {
                conn.Close();
               // MessageBox.Show("The image doesnot exits");
            }

        }

        private void t_search_TextChanged(object sender, EventArgs e)
        {
            string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection(cs);
            conn = new SqlConnection(cs);
            conn.Open();
            adapt = new SqlDataAdapter("select * from Player_Information where PlayerID like '" + t_search.Text + "%'", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Filter = "JPG files (*.jpg)|*.jpg|GIF files(*.gif)|*.gif|All files(*.*)|*.*";
                dlg.Title = "Select Player_Photo";
                if (dlg.ShowDialog()==DialogResult.OK)
                {
                    imgLoc = dlg.FileName.ToString();
                    p_image.ImageLocation = imgLoc;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
                 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();



                MessageBox.Show(" Successfully cleared record for Competition_Information  ");
                conn.Close();
                p_playerid.Text = "";
                p_firstName.Text = "";
                p_lastName.Text = "";
                p_dob.Text = "";
                p_address.Text = "";
                p_contact.Text = "";
                Gender = "";
                p_nationality.Text = "";
                p_teamid.Text = "";
                p_position.Text = "";
                p_height.Text = "";
                p_image.Image = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          


        }

        private void dataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {

        }
    }
    
    }
    

