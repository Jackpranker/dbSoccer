﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ebo_town_football_Database
{
    public partial class Refree_information : Form
    {
        SqlDataAdapter adapt;
        DataTable dt;
        String Gender;
        public Refree_information()
        {
            InitializeComponent();
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void r_Save_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into Refree_Information(RefreeID, First_Name, Last_Name, Date_of_Birth ,Contact, Gender, Date ,Booking ,Address , VenueID) values" +
                    " ('" + r_refreeid.Text + "','" + r_firstName.Text + "','" + r_lastName.Text + "','" + r_dob.Text + "','" + r_contact.Text + "','" + Gender + "','" + r_date.Text + "','" + r_booking + "','" + r_address.Text + "','" + r_venueid.Text + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully saved record for Refree_Information  " +  " First_name " + r_firstName.Text);
                conn.Close();
                

            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist "  + ex.Message);
            }
        }

        private void r_male_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "male";
        }

        private void r_female_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "female";
        }

        private void Refree_information_Load(object sender, EventArgs e)
        {
            try
            {

                string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
                SqlConnection conn = new SqlConnection();
                conn = new SqlConnection(cs);
                conn.Open();
                //put the name of the table
                adapt = new SqlDataAdapter("select * from Refree_Information", conn);
                dt = new DataTable();
                adapt.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Data view" + ex.Message);
                //conn.Close();

            }
        }

        private void r_update_Click(object sender, EventArgs e)
        {

            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "update Refree_Information set RefreeID ='" + r_refreeid.Text + "',First_Name=" +
                    "'" + r_firstName.Text + "',Last_Name='" + r_lastName.Text + "',Date_of_Birth='" + r_dob.Text + "',Contact='" +
                    r_contact.Text + "' ,Gender ='" +Gender + "' ,Date='" +r_date.Text + "' ,Booking ='" + r_booking.Text + "" +
                    "',Address ='" + r_address.Text + "', VenueID ='" + r_venueid.Text + "' where RefreeID='" +r_refreeid.Text +
                    "'  ";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully Updates record for Refree_Information  " + " RefreeID " + r_refreeid.Text);
                conn.Close();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Updates check it might exist " + ex.Message);
            }
        }

        private void r_delete_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "delete  from Refree_Information where  RefreeID = '" + r_refreeid.Text + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully delete record for Refree_Information  " + "RefreeID" + r_refreeid.Text);
                conn.Close();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be delete check it might exist " + ex.Message);
            }
        }

        private void t_search_TextChanged(object sender, EventArgs e)
        {
            string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection(cs);
            conn = new SqlConnection(cs);
            conn.Open();
            adapt = new SqlDataAdapter("select * from Refree_Information where RefreeID like '" + t_search.Text + "%'", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
            t_search.Text = "";
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void r_refreeid_TextChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source = JP\\SQLEXPRESS; Initial Catalog = Ebo_town_football_database; Integrated Security = True");
            conn.Open();
            if (r_refreeid.Text != "")
            {
                SqlCommand cmd = new SqlCommand("Select First_Name, Last_Name,Date_of_Birth,Contact,Gender,Date,Booking,Address,VenueID from Refree_Information where RefreeID= @RefreeID", conn);
                cmd.Parameters.AddWithValue("@RefreeID", int.Parse(r_refreeid.Text));
                SqlDataReader da = cmd.ExecuteReader();
                while (da.Read())
                {
                    r_firstName.Text = da.GetValue(0).ToString();
                    r_lastName.Text = da.GetValue(1).ToString();
                    r_dob.Text = da.GetValue(2).ToString();
                    r_contact.Text = da.GetValue(3).ToString();
                    Gender = da.GetValue(4).ToString();
                    r_date.Text = da.GetValue(5).ToString();
                    r_booking.Text = da.GetValue(6).ToString();
                    r_address.Text = da.GetValue(7).ToString();
                    r_venueid.Text = da.GetValue(8).ToString();

                }
                conn.Close();

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();



                MessageBox.Show(" Successfully cleared record for Competition_Information  ");
                conn.Close();
                r_refreeid.Text = "";
                r_firstName.Text = "";
                r_lastName.Text = "";
                r_dob.Text = "";
                r_contact.Text = "";
                Gender = "";
                r_date.Text = "";
                r_address.Text = "";
                r_booking.Text = "";
                r_venueid.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " + ex.Message);
            }
        }
    }
    }
    
    

