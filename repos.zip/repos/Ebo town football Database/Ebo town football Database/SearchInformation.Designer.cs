﻿
namespace Ebo_town_football_Database
{
    partial class SearchInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchInformation));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.t_search = new System.Windows.Forms.TextBox();
            this.CompetitionInformation = new System.Windows.Forms.DataGridView();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.GoalInformation = new System.Windows.Forms.DataGridView();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.VenueInformation = new System.Windows.Forms.DataGridView();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.PlayerInformation = new System.Windows.Forms.DataGridView();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.RefreeInformation = new System.Windows.Forms.DataGridView();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.TeamInformation = new System.Windows.Forms.DataGridView();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.MatchInformation = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CompetitionInformation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GoalInformation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VenueInformation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerInformation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RefreeInformation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TeamInformation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MatchInformation)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(28, 186);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(53, 20);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 66;
            this.pictureBox1.TabStop = false;
            // 
            // t_search
            // 
            this.t_search.BackColor = System.Drawing.Color.White;
            this.t_search.Font = new System.Drawing.Font("Josy Wine", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t_search.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.t_search.Location = new System.Drawing.Point(54, 186);
            this.t_search.Multiline = true;
            this.t_search.Name = "t_search";
            this.t_search.Size = new System.Drawing.Size(231, 19);
            this.t_search.TabIndex = 65;
            this.t_search.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.t_search.TextChanged += new System.EventHandler(this.t_search_TextChanged);
            // 
            // CompetitionInformation
            // 
            this.CompetitionInformation.AllowUserToOrderColumns = true;
            this.CompetitionInformation.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.CompetitionInformation.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.CompetitionInformation.BackgroundColor = System.Drawing.Color.Gray;
            this.CompetitionInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.CompetitionInformation.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.CompetitionInformation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CompetitionInformation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CompetitionInformation.GridColor = System.Drawing.Color.Gray;
            this.CompetitionInformation.Location = new System.Drawing.Point(28, 33);
            this.CompetitionInformation.Name = "CompetitionInformation";
            this.CompetitionInformation.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.CompetitionInformation.Size = new System.Drawing.Size(496, 146);
            this.CompetitionInformation.TabIndex = 64;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(607, 185);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(53, 20);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 69;
            this.pictureBox2.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.Font = new System.Drawing.Font("Josy Wine", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox1.Location = new System.Drawing.Point(633, 185);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(247, 19);
            this.textBox1.TabIndex = 68;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // GoalInformation
            // 
            this.GoalInformation.AllowUserToOrderColumns = true;
            this.GoalInformation.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GoalInformation.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.GoalInformation.BackgroundColor = System.Drawing.Color.Gray;
            this.GoalInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.GoalInformation.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.GoalInformation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GoalInformation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.GoalInformation.GridColor = System.Drawing.Color.Gray;
            this.GoalInformation.Location = new System.Drawing.Point(605, 33);
            this.GoalInformation.Name = "GoalInformation";
            this.GoalInformation.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.GoalInformation.Size = new System.Drawing.Size(593, 146);
            this.GoalInformation.TabIndex = 67;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(28, 396);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(53, 16);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 72;
            this.pictureBox3.TabStop = false;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.Font = new System.Drawing.Font("Josy Wine", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox2.Location = new System.Drawing.Point(54, 396);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(231, 16);
            this.textBox2.TabIndex = 71;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // VenueInformation
            // 
            this.VenueInformation.AllowUserToOrderColumns = true;
            this.VenueInformation.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.VenueInformation.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.VenueInformation.BackgroundColor = System.Drawing.Color.Gray;
            this.VenueInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.VenueInformation.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.VenueInformation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.VenueInformation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.VenueInformation.GridColor = System.Drawing.Color.Gray;
            this.VenueInformation.Location = new System.Drawing.Point(28, 243);
            this.VenueInformation.Name = "VenueInformation";
            this.VenueInformation.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.VenueInformation.Size = new System.Drawing.Size(496, 146);
            this.VenueInformation.TabIndex = 70;
            this.VenueInformation.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(607, 395);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(53, 17);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 75;
            this.pictureBox4.TabStop = false;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.White;
            this.textBox3.Font = new System.Drawing.Font("Josy Wine", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox3.Location = new System.Drawing.Point(633, 395);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(262, 16);
            this.textBox3.TabIndex = 74;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // PlayerInformation
            // 
            this.PlayerInformation.AllowUserToOrderColumns = true;
            this.PlayerInformation.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.PlayerInformation.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.PlayerInformation.BackgroundColor = System.Drawing.Color.Gray;
            this.PlayerInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PlayerInformation.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.PlayerInformation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PlayerInformation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PlayerInformation.GridColor = System.Drawing.Color.Gray;
            this.PlayerInformation.Location = new System.Drawing.Point(605, 243);
            this.PlayerInformation.Name = "PlayerInformation";
            this.PlayerInformation.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.PlayerInformation.Size = new System.Drawing.Size(582, 146);
            this.PlayerInformation.TabIndex = 73;
            this.PlayerInformation.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.PlayerInformation_DataError);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(28, 598);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(53, 18);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 78;
            this.pictureBox5.TabStop = false;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.White;
            this.textBox4.Font = new System.Drawing.Font("Josy Wine", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox4.Location = new System.Drawing.Point(54, 598);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(231, 17);
            this.textBox4.TabIndex = 77;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // RefreeInformation
            // 
            this.RefreeInformation.AllowUserToOrderColumns = true;
            this.RefreeInformation.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.RefreeInformation.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.RefreeInformation.BackgroundColor = System.Drawing.Color.Gray;
            this.RefreeInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.RefreeInformation.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.RefreeInformation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.RefreeInformation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RefreeInformation.GridColor = System.Drawing.Color.Gray;
            this.RefreeInformation.Location = new System.Drawing.Point(28, 445);
            this.RefreeInformation.Name = "RefreeInformation";
            this.RefreeInformation.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.RefreeInformation.Size = new System.Drawing.Size(496, 146);
            this.RefreeInformation.TabIndex = 76;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(607, 597);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(53, 18);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 81;
            this.pictureBox6.TabStop = false;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.White;
            this.textBox5.Font = new System.Drawing.Font("Josy Wine", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox5.Location = new System.Drawing.Point(633, 597);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(262, 17);
            this.textBox5.TabIndex = 80;
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // TeamInformation
            // 
            this.TeamInformation.AllowUserToOrderColumns = true;
            this.TeamInformation.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.TeamInformation.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.TeamInformation.BackgroundColor = System.Drawing.Color.Gray;
            this.TeamInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TeamInformation.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.TeamInformation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TeamInformation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TeamInformation.GridColor = System.Drawing.Color.Gray;
            this.TeamInformation.Location = new System.Drawing.Point(605, 445);
            this.TeamInformation.Name = "TeamInformation";
            this.TeamInformation.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TeamInformation.Size = new System.Drawing.Size(582, 146);
            this.TeamInformation.TabIndex = 79;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(524, 816);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(58, 18);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 84;
            this.pictureBox7.TabStop = false;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.White;
            this.textBox6.Font = new System.Drawing.Font("Josy Wine", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox6.Location = new System.Drawing.Point(567, 816);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(185, 17);
            this.textBox6.TabIndex = 83;
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // MatchInformation
            // 
            this.MatchInformation.AllowUserToOrderColumns = true;
            this.MatchInformation.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.MatchInformation.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.MatchInformation.BackgroundColor = System.Drawing.Color.Gray;
            this.MatchInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MatchInformation.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.MatchInformation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MatchInformation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MatchInformation.GridColor = System.Drawing.Color.Gray;
            this.MatchInformation.Location = new System.Drawing.Point(28, 620);
            this.MatchInformation.Name = "MatchInformation";
            this.MatchInformation.Size = new System.Drawing.Size(1158, 214);
            this.MatchInformation.TabIndex = 82;
            this.MatchInformation.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MatchInformation_CellContentClick);
            this.MatchInformation.DragDrop += new System.Windows.Forms.DragEventHandler(this.MatchInformation_DragDrop);
            this.MatchInformation.DoubleClick += new System.EventHandler(this.MatchInformation_DoubleClick);
            this.MatchInformation.Resize += new System.EventHandler(this.MatchInformation_Resize);
            // 
            // SearchInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1216, 749);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.TeamInformation);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.RefreeInformation);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.PlayerInformation);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.VenueInformation);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.GoalInformation);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.t_search);
            this.Controls.Add(this.CompetitionInformation);
            this.Controls.Add(this.MatchInformation);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Lucida Bright", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SearchInformation";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SearchInformation";
            this.Load += new System.EventHandler(this.SearchInformation_Load);
            this.Shown += new System.EventHandler(this.SearchInformation_Shown);
            this.ResizeEnd += new System.EventHandler(this.SearchInformation_ResizeEnd);
            this.Scroll += new System.Windows.Forms.ScrollEventHandler(this.SearchInformation_Scroll);
            this.Click += new System.EventHandler(this.SearchInformation_Click);
            this.DoubleClick += new System.EventHandler(this.SearchInformation_DoubleClick);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CompetitionInformation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GoalInformation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VenueInformation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerInformation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RefreeInformation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TeamInformation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MatchInformation)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox t_search;
        private System.Windows.Forms.DataGridView CompetitionInformation;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView GoalInformation;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.DataGridView VenueInformation;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.DataGridView PlayerInformation;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.DataGridView RefreeInformation;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.DataGridView TeamInformation;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.DataGridView MatchInformation;
    }
}