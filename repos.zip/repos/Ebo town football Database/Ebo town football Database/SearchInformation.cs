﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Ebo_town_football_Database
{
    public partial class SearchInformation : Form
    {
        SqlDataAdapter adapt;
        DataTable dt;
        public SearchInformation()
        {
            InitializeComponent();
        }

        private void SearchInformation_Load(object sender, EventArgs e)
        {
            try
            {

                string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
                SqlConnection conn = new SqlConnection();
                conn = new SqlConnection(cs);
                conn.Open();
                //put the name of the table
                adapt = new SqlDataAdapter("select * from Competition_Information", conn);
                dt = new DataTable();
                adapt.Fill(dt);
                CompetitionInformation.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Data view" + ex.Message);
                //conn.Close();

            }
            try
            {

                string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
                SqlConnection conn = new SqlConnection();
                conn = new SqlConnection(cs);
                conn.Open();
                //put the name of the table
                adapt = new SqlDataAdapter("select * from Goal_Information", conn);
                dt = new DataTable();
                adapt.Fill(dt);
                GoalInformation.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Data view" + ex.Message);
                //conn.Close();

            }
            try
            {

                string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
                SqlConnection conn = new SqlConnection();
                conn = new SqlConnection(cs);
                conn.Open();
                //put the name of the table
                adapt = new SqlDataAdapter("select * from Match_Information", conn);
                dt = new DataTable();
                adapt.Fill(dt);
                MatchInformation.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Data view" + ex.Message);
                //conn.Close();

            }
            try
            {

                string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
                SqlConnection conn = new SqlConnection();
                conn = new SqlConnection(cs);
                conn.Open();
                //put the name of the table
                adapt = new SqlDataAdapter("select * from Player_Information", conn);
                dt = new DataTable();
                adapt.Fill(dt);
                PlayerInformation.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Data view" + ex.Message);
                //conn.Close();

            }
            try
            {

                string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
                SqlConnection conn = new SqlConnection();
                conn = new SqlConnection(cs);
                conn.Open();
                //put the name of the table
                adapt = new SqlDataAdapter("select * from Refree_Information", conn);
                dt = new DataTable();
                adapt.Fill(dt);
                RefreeInformation.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Data view" + ex.Message);
                //conn.Close();

            }
            try
            {

                string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
                SqlConnection conn = new SqlConnection();
                conn = new SqlConnection(cs);
                conn.Open();
                //put the name of the table
                adapt = new SqlDataAdapter("select * from Team_Information", conn);
                dt = new DataTable();
                adapt.Fill(dt);
                TeamInformation.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Data view" + ex.Message);
                //conn.Close();

            }
            try
            {

                string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
                SqlConnection conn = new SqlConnection();
                conn = new SqlConnection(cs);
                conn.Open();
                //put the name of the table
                adapt = new SqlDataAdapter("select * from Venue_Information", conn);
                dt = new DataTable();
                adapt.Fill(dt);
                VenueInformation.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Data view" + ex.Message);
                //conn.Close();

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void t_search_TextChanged(object sender, EventArgs e)
        {
            string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection(cs);
            conn = new SqlConnection(cs);
            conn.Open();
            adapt = new SqlDataAdapter("select * from Competition_Information where CompetitionID like '" + t_search.Text + "%'", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            CompetitionInformation.DataSource = dt;
            conn.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection(cs);
            conn = new SqlConnection(cs);
            conn.Open();
            adapt = new SqlDataAdapter("select * from Goal_Information where GoalID like '" + textBox1.Text + "%'", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            GoalInformation.DataSource = dt;
            conn.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection(cs);
            conn = new SqlConnection(cs);
            conn.Open();
            adapt = new SqlDataAdapter("select * from Venue_Information where VenueID like '" + textBox2.Text + "%'", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            VenueInformation.DataSource = dt;
            conn.Close();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection(cs);
            conn = new SqlConnection(cs);
            conn.Open();
            adapt = new SqlDataAdapter("select * from Player_Information where PlayerID like '" + textBox3.Text + "%'", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            PlayerInformation.DataSource = dt;
            conn.Close();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection(cs);
            conn = new SqlConnection(cs);
            conn.Open();
            adapt = new SqlDataAdapter("select * from Refree_Information where RefreeID like '" + textBox4.Text + "%'", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            RefreeInformation.DataSource = dt;
            conn.Close();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection(cs);
            conn = new SqlConnection(cs);
            conn.Open();
            adapt = new SqlDataAdapter("select * from Team_Information where TeamID like '" + textBox5.Text + "%'", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            TeamInformation.DataSource = dt;
            conn.Close();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection(cs);
            conn = new SqlConnection(cs);
            conn.Open();
            adapt = new SqlDataAdapter("select * from Match_Information where MatchID like '" + textBox6.Text + "%'", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            MatchInformation.DataSource = dt;
            conn.Close();
        }

        private void MatchInformation_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void SearchInformation_DoubleClick(object sender, EventArgs e)
        {

        }

        private void SearchInformation_ResizeEnd(object sender, EventArgs e)
        {

        }

        private void SearchInformation_Scroll(object sender, ScrollEventArgs e)
        {

        }

        private void SearchInformation_Click(object sender, EventArgs e)
        {

        }

        private void SearchInformation_Shown(object sender, EventArgs e)
        {

        }

        private void PlayerInformation_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {

        }

        private void MatchInformation_Resize(object sender, EventArgs e)
        {

        }

        private void MatchInformation_DragDrop(object sender, DragEventArgs e)
        {

        }

        private void MatchInformation_DoubleClick(object sender, EventArgs e)
        {

        }
    }
}
