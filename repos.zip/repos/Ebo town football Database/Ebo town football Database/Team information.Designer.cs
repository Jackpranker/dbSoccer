﻿namespace Ebo_town_football_Database
{
    partial class Team_Information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Team_Information));
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.t_name = new System.Windows.Forms.TextBox();
            this.t_contact = new System.Windows.Forms.TextBox();
            this.t_est = new System.Windows.Forms.TextBox();
            this.t_address = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.t_Save = new System.Windows.Forms.Button();
            this.t_delete = new System.Windows.Forms.Button();
            this.t_update = new System.Windows.Forms.Button();
            this.t_teamid = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.t_search = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(54, 197);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Establishment";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(54, 128);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Address";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(54, 161);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Contact";
            // 
            // t_name
            // 
            this.t_name.Location = new System.Drawing.Point(121, 87);
            this.t_name.Name = "t_name";
            this.t_name.Size = new System.Drawing.Size(140, 22);
            this.t_name.TabIndex = 6;
            // 
            // t_contact
            // 
            this.t_contact.Location = new System.Drawing.Point(121, 158);
            this.t_contact.Name = "t_contact";
            this.t_contact.Size = new System.Drawing.Size(140, 22);
            this.t_contact.TabIndex = 7;
            this.t_contact.Text = "+220";
            // 
            // t_est
            // 
            this.t_est.Location = new System.Drawing.Point(158, 194);
            this.t_est.Name = "t_est";
            this.t_est.Size = new System.Drawing.Size(103, 22);
            this.t_est.TabIndex = 8;
            // 
            // t_address
            // 
            this.t_address.Location = new System.Drawing.Point(121, 125);
            this.t_address.Name = "t_address";
            this.t_address.Size = new System.Drawing.Size(140, 22);
            this.t_address.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.DimGray;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Font = new System.Drawing.Font("Mary Jane Antique", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(34, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(262, 41);
            this.label6.TabIndex = 10;
            this.label6.Text = "TEAM PROFILE";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // t_Save
            // 
            this.t_Save.BackColor = System.Drawing.Color.Lime;
            this.t_Save.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.t_Save.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.t_Save.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.t_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.t_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.t_Save.Location = new System.Drawing.Point(158, 230);
            this.t_Save.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.t_Save.Name = "t_Save";
            this.t_Save.Size = new System.Drawing.Size(60, 33);
            this.t_Save.TabIndex = 12;
            this.t_Save.Text = "Save";
            this.t_Save.UseVisualStyleBackColor = false;
            this.t_Save.Click += new System.EventHandler(this.t_Save_Click);
            // 
            // t_delete
            // 
            this.t_delete.BackColor = System.Drawing.Color.Red;
            this.t_delete.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.t_delete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.t_delete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.t_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.t_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t_delete.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.t_delete.Location = new System.Drawing.Point(224, 230);
            this.t_delete.Name = "t_delete";
            this.t_delete.Size = new System.Drawing.Size(59, 35);
            this.t_delete.TabIndex = 15;
            this.t_delete.Text = "Delete";
            this.t_delete.UseVisualStyleBackColor = false;
            this.t_delete.Click += new System.EventHandler(this.t_delete_Click);
            // 
            // t_update
            // 
            this.t_update.BackColor = System.Drawing.Color.Blue;
            this.t_update.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.t_update.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.t_update.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.t_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.t_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t_update.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.t_update.Location = new System.Drawing.Point(82, 231);
            this.t_update.Name = "t_update";
            this.t_update.Size = new System.Drawing.Size(69, 32);
            this.t_update.TabIndex = 14;
            this.t_update.Text = "Update";
            this.t_update.UseVisualStyleBackColor = false;
            this.t_update.Click += new System.EventHandler(this.t_update_Click);
            // 
            // t_teamid
            // 
            this.t_teamid.Location = new System.Drawing.Point(119, 53);
            this.t_teamid.Name = "t_teamid";
            this.t_teamid.Size = new System.Drawing.Size(140, 22);
            this.t_teamid.TabIndex = 17;
            this.t_teamid.TextChanged += new System.EventHandler(this.t_teamid_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 15);
            this.label1.TabIndex = 16;
            this.label1.Text = "TeamID";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Gray;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView1.GridColor = System.Drawing.Color.Gray;
            this.dataGridView1.Location = new System.Drawing.Point(302, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridView1.Size = new System.Drawing.Size(542, 219);
            this.dataGridView1.TabIndex = 18;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // t_search
            // 
            this.t_search.BackColor = System.Drawing.Color.White;
            this.t_search.Font = new System.Drawing.Font("Josy Wine", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t_search.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.t_search.Location = new System.Drawing.Point(302, 239);
            this.t_search.Name = "t_search";
            this.t_search.Size = new System.Drawing.Size(251, 22);
            this.t_search.TabIndex = 20;
            this.t_search.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.t_search.TextChanged += new System.EventHandler(this.t_search_TextChanged);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Lucida Fax", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(12, 231);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(64, 30);
            this.button2.TabIndex = 25;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(302, 239);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(46, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 63;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Team_Information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(849, 351);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.t_search);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.t_teamid);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.t_delete);
            this.Controls.Add(this.t_update);
            this.Controls.Add(this.t_Save);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.t_address);
            this.Controls.Add(this.t_est);
            this.Controls.Add(this.t_contact);
            this.Controls.Add(this.t_name);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Lucida Bright", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Team_Information";
            this.Opacity = 0.9D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Team Information";
            this.Load += new System.EventHandler(this.Team_Information_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox t_name;
        private System.Windows.Forms.TextBox t_contact;
        private System.Windows.Forms.TextBox t_est;
        private System.Windows.Forms.TextBox t_address;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button t_Save;
        private System.Windows.Forms.Button t_delete;
        private System.Windows.Forms.Button t_update;
        private System.Windows.Forms.TextBox t_teamid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox t_search;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}