﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ebo_town_football_Database
{
    public partial class Venue_information : Form
    {
        SqlDataAdapter adapt;
        DataTable dt;
        public Venue_information()
        {
            InitializeComponent();
        }

        private void Venue_information_Load(object sender, EventArgs e)
        {
             try
            {

                string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
                SqlConnection conn = new SqlConnection();
                conn = new SqlConnection(cs);
                conn.Open();
                //put the name of the table
                adapt = new SqlDataAdapter("select * from Venue_Information", conn);
                dt = new DataTable();
                adapt.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Data view" + ex.Message);
                //conn.Close();

            }
        }

        private void v_Save_Click(object sender, EventArgs e)
        {

            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into Venue_Information(VenueID,Name,Time,Date) values('" + v_venueid.Text + "','" + v_name.Text + "'," +
                    "'" + v_time.Text + "','" + v_date.Text + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully saved record for  Venue_Information  " + " Name " + v_name.Text);
                conn.Close();
              
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist "  + ex.Message);
            }
        }

        private void v_update_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "update Venue_Information set VenueID ='" + v_venueid.Text + "',Name=" +
                    "'" + v_name.Text + "',Time='" + v_time.Text + "',Date='" + v_date.Text + "' where VenueID='" + v_venueid.Text +
                    "'  ";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully updates record for Venue_Information  " + " VenueID " + v_venueid.Text);
                conn.Close();
              
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Updates check it might exist " + ex.Message);
            }
        }

        private void v_delete_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "delete  from Venue_Information where  venueD = '" +v_venueid.Text + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully delete record for Venue_Information  " + "VenueID" + v_venueid.Text);
                conn.Close();
             
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be delete check it might exist " + ex.Message);
            }
        }

        private void t_search_TextChanged(object sender, EventArgs e)
        {
            string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection(cs);
            conn = new SqlConnection(cs);
            conn.Open();
            adapt = new SqlDataAdapter("select * from Venue_Information where VenueID like '" + t_search.Text + "%'", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
            
        }

        private void v_venueid_TextChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source = JP\\SQLEXPRESS; Initial Catalog = Ebo_town_football_database; Integrated Security = True");
            conn.Open();
            if (v_venueid.Text != "")
            {
                SqlCommand cmd = new SqlCommand("Select Name, Time,Date from Venue_Information where VenueID= @VenueID", conn);
                cmd.Parameters.AddWithValue("@VenueID", int.Parse(v_venueid.Text));
                SqlDataReader da = cmd.ExecuteReader();
                while (da.Read())
                {
                    v_name.Text = da.GetValue(0).ToString();
                    v_time.Text = da.GetValue(1).ToString();
                    v_date.Text = da.GetValue(2).ToString();
                    
                }
                conn.Close();

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();



                MessageBox.Show(" Successfully cleared record for Competition_Information  ");
                conn.Close();
                v_venueid.Text = "";
                v_name.Text = "";
                v_time.Text = "";
                v_date.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
    }

