﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ebo_town_football_Database
{
    public partial class Competition_information : Form
    {
        public Competition_information()
        {
            InitializeComponent();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Competition_information_Load(object sender, EventArgs e)
        {

        }

        private void c_Save_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into Competition_Information(CompetitionID,Name,Year,TeamID,Remarks) values('"+ c_competitionid+"','" + c_name.Text + "','" + c_year.Text + "','" + c_teamid.Text + "','" + c_remarks.Text + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();    
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully saved record for Competition_Information  "  + " Name " + c_name.Text);
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " + ex.Message);
            }
        }

        private void c_remarks_TextChanged(object sender, EventArgs e)
        {

        }

        private void c_year_TextChanged(object sender, EventArgs e)
        {

        }

        private void c_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void c_teamid_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "delete  from Competition_Information where  CompetitionID = '"+ c_competitionid.Text+"'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully delete record for Competition_Information  " + "CompetitonID" + c_competitionid.Text);
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be delete check it might exist " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "update Competition_Information set CompetitionID ='"+ c_competitionid.Text+"', Name='" + c_name.Text + "',Year='" + c_year.Text + "',TeamID='" + c_teamid.Text + "',Remarks='" + c_remarks.Text + "' where CompetitionID='" +c_competitionid.Text+ "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully Updates record for Competition_Information  " + " CompetitionID " + c_competitionid.Text);
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Updates check it might exist " + ex.Message);
            }
        }
    }
    }

       
    
    

