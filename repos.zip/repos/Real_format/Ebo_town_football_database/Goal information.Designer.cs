﻿namespace Ebo_town_football_Database
{
    partial class Goal_information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.g_teamid = new System.Windows.Forms.TextBox();
            this.g_scorer = new System.Windows.Forms.TextBox();
            this.g_goalTime = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.g_Comment = new System.Windows.Forms.TextBox();
            this.Comment = new System.Windows.Forms.Label();
            this.g_Save = new System.Windows.Forms.Button();
            this.g_delete = new System.Windows.Forms.Button();
            this.g_update = new System.Windows.Forms.Button();
            this.g_goalid = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(59, 89);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "TeamID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(64, 121);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Scorer";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(44, 152);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Goal_time";
            // 
            // g_teamid
            // 
            this.g_teamid.Location = new System.Drawing.Point(124, 86);
            this.g_teamid.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.g_teamid.Name = "g_teamid";
            this.g_teamid.Size = new System.Drawing.Size(132, 22);
            this.g_teamid.TabIndex = 6;
            // 
            // g_scorer
            // 
            this.g_scorer.Location = new System.Drawing.Point(124, 121);
            this.g_scorer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.g_scorer.Name = "g_scorer";
            this.g_scorer.Size = new System.Drawing.Size(132, 22);
            this.g_scorer.TabIndex = 7;
            this.g_scorer.TextChanged += new System.EventHandler(this.g_scorer_TextChanged);
            // 
            // g_goalTime
            // 
            this.g_goalTime.Location = new System.Drawing.Point(124, 152);
            this.g_goalTime.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.g_goalTime.Name = "g_goalTime";
            this.g_goalTime.Size = new System.Drawing.Size(132, 22);
            this.g_goalTime.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(98, 24);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(171, 31);
            this.label6.TabIndex = 10;
            this.label6.Text = "GOAL INFO";
            // 
            // g_Comment
            // 
            this.g_Comment.Location = new System.Drawing.Point(124, 180);
            this.g_Comment.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.g_Comment.Name = "g_Comment";
            this.g_Comment.Size = new System.Drawing.Size(132, 22);
            this.g_Comment.TabIndex = 12;
            this.g_Comment.TextChanged += new System.EventHandler(this.g_Comment_TextChanged);
            // 
            // Comment
            // 
            this.Comment.AutoSize = true;
            this.Comment.Location = new System.Drawing.Point(44, 180);
            this.Comment.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Comment.Name = "Comment";
            this.Comment.Size = new System.Drawing.Size(71, 15);
            this.Comment.TabIndex = 11;
            this.Comment.Text = "Comment";
            // 
            // g_Save
            // 
            this.g_Save.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.g_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.g_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.g_Save.Location = new System.Drawing.Point(153, 207);
            this.g_Save.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.g_Save.Name = "g_Save";
            this.g_Save.Size = new System.Drawing.Size(75, 23);
            this.g_Save.TabIndex = 13;
            this.g_Save.Text = "Save";
            this.g_Save.UseVisualStyleBackColor = false;
            this.g_Save.Click += new System.EventHandler(this.g_Save_Click);
            // 
            // g_delete
            // 
            this.g_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.g_delete.Location = new System.Drawing.Point(234, 207);
            this.g_delete.Name = "g_delete";
            this.g_delete.Size = new System.Drawing.Size(75, 23);
            this.g_delete.TabIndex = 15;
            this.g_delete.Text = "Delete";
            this.g_delete.UseVisualStyleBackColor = true;
            this.g_delete.Click += new System.EventHandler(this.g_delete_Click);
            // 
            // g_update
            // 
            this.g_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.g_update.Location = new System.Drawing.Point(72, 207);
            this.g_update.Name = "g_update";
            this.g_update.Size = new System.Drawing.Size(75, 23);
            this.g_update.TabIndex = 14;
            this.g_update.Text = "Update";
            this.g_update.UseVisualStyleBackColor = true;
            this.g_update.Click += new System.EventHandler(this.g_update_Click);
            // 
            // g_goalid
            // 
            this.g_goalid.Location = new System.Drawing.Point(124, 58);
            this.g_goalid.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.g_goalid.Name = "g_goalid";
            this.g_goalid.Size = new System.Drawing.Size(132, 22);
            this.g_goalid.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 61);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 15);
            this.label1.TabIndex = 16;
            this.label1.Text = "GoalID";
            // 
            // Goal_information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(387, 303);
            this.Controls.Add(this.g_goalid);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.g_delete);
            this.Controls.Add(this.g_update);
            this.Controls.Add(this.g_Save);
            this.Controls.Add(this.g_Comment);
            this.Controls.Add(this.Comment);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.g_goalTime);
            this.Controls.Add(this.g_scorer);
            this.Controls.Add(this.g_teamid);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Lucida Bright", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Goal_information";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Goal_information";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox g_teamid;
        private System.Windows.Forms.TextBox g_scorer;
        private System.Windows.Forms.TextBox g_goalTime;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox g_Comment;
        private System.Windows.Forms.Label Comment;
        private System.Windows.Forms.Button g_Save;
        private System.Windows.Forms.Button g_delete;
        private System.Windows.Forms.Button g_update;
        private System.Windows.Forms.TextBox g_goalid;
        private System.Windows.Forms.Label label1;
    }
}