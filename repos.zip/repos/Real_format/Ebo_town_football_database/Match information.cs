﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ebo_town_football_Database
{
    public partial class Match_information : Form
    {
        public Match_information()
        {
            InitializeComponent();
        }

        private void Match_information_Load(object sender, EventArgs e)
        {

        }

        private void m_Save_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into Match_Information(MatchID,TeamID,GoalID,CompetitionID,Winner,Kick_off_Time,RefreeID,Home_vs_away,VenueID,Match_Statistics,Date,Remarks) " +
                    "values('" + m_matchid.Text + "','" + m_teamid.Text + "','" + m_goalid.Text + "','" +m_competitionid.Text + "','" + m_winner.Text + "','" + m_kick.Text + "'," +
                    "'" + m_refreeid.Text + "','" + m_Home_vs_away.Text + "','" + m_venueid.Text + "','" + m_matchStatistic.Text + "','" + m_date.Text + "','" + m_remarks.Text + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully saved record for Match_Information  "  + " Winner " + m_winner.Text);
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " + ex.Message);
            }
        }

        private void m_update_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "update Match_Information set MatchID ='" + m_matchid.Text + "'," +
                    " TeamID='" + m_matchid.Text + "',GoalID='" + m_goalid.Text + "',CompetitionID='" + m_competitionid.Text + "'," +
                    "Winner='" +m_winner.Text + "' ,Kick_off_Time ='" + m_kick.Text + "', RefreeID ='" + m_refreeid.Text + "'" +
                    ",Home_vs_away ='" + m_Home_vs_away.Text + "',VenueID ='" + m_venueid.Text + "', " +
                    "Match_Statistics ='" + m_matchStatistic.Text + "',Date ='" + m_date.Text + "', Remarks ='" + m_remarks.Text + "'" +
                    " where MatchID='" + m_matchid.Text + "'";
                cmd.CommandType = CommandType.Text; 
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully Updates record for Match_Information  " + " MatchID " + m_matchid.Text);
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Updates check it might exist " + ex.Message);
            }
        }

        private void m_delete_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "delete  from Match_Information where  MatchID = '" + m_matchid.Text + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully delete record for Competition_Information  " + "MatchID" + m_matchid.Text);
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be delete check it might exist " + ex.Message);
            }
        }
    }
    }
    
    

