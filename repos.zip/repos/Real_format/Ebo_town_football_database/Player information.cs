﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;




namespace Ebo_town_football_Database
{
    public partial class Player_information : Form
    {
        string Gender;
        public Player_information()
        {
            InitializeComponent();
        }

        private void Player_information_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void p_Save_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_Database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into Player_Information(PlayerID,First_Name,Last_Name,Date_of_Birth,Address,Contact,Gender,Nationality,TeamID,Position,Height,Photo) " +
                    "values('" + p_playerid.Text + "','" + p_firstName.Text + "','" + p_lastName.Text + "','" + p_dob.Text + "','" + p_address.Text + "','" + p_contact.Text + "'," +
                    "'" +Gender+ "','" + p_nationality.Text + "','" + p_teamid.Text + "','" + p_position.Text + "','" + p_height.Text + "','" + p_image.Image + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully saved record for Player Information  " + " First_name " + p_firstName.Text);
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " + ex.Message);
            }
        }

        private void p_female_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "Female";
        }

        private void p_male_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "male";
        }

        private void p_update_Click(object sender, EventArgs e)
        {

            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_Database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "update Player_Information set PlayerID ='" + p_playerid.Text + "',First_Name='" + p_firstName.Text + "',Last_Name='" + p_lastName.Text + "',Date_of_Birth='" + p_dob.Text + "',Address='" + p_address.Text + "' ,Contact ='" + p_contact.Text + "' ,Gender='"+Gender+"' ,Nationality ='" + p_nationality.Text + "',TeamID ='" + p_teamid.Text + "', Position ='" + p_position.Text + "',Height ='" + p_height.Text + "' where PlayerID='" + p_playerid.Text + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully Updates record for Player_Information  " + " PlayerID " + p_playerid.Text);
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Updates check it might exist " + ex.Message);
            }
        }

        private void p_delte_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "delete  from Player_Information where  PlayerID = '" + p_playerid.Text + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully delete record for Player_Information  " + "PlayerID" + p_playeridddd.Text);
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be delete check it might exist " + ex.Message);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
    
    }
    

