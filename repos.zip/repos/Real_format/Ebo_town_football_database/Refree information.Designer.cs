﻿namespace Ebo_town_football_Database
{
    partial class Refree_information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.r_date = new System.Windows.Forms.DateTimePicker();
            this.r_dob = new System.Windows.Forms.DateTimePicker();
            this.r_female = new System.Windows.Forms.RadioButton();
            this.r_male = new System.Windows.Forms.RadioButton();
            this.r_firstName = new System.Windows.Forms.TextBox();
            this.r_lastName = new System.Windows.Forms.TextBox();
            this.r_contact = new System.Windows.Forms.TextBox();
            this.r_booking = new System.Windows.Forms.TextBox();
            this.r_address = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.r_venueid = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.r_Save = new System.Windows.Forms.Button();
            this.r_delete = new System.Windows.Forms.Button();
            this.r_update = new System.Windows.Forms.Button();
            this.r_refreeid = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(87, 174);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Contact";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(71, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last_Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(71, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "First_Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(73, 263);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Booking(s)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(91, 202);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Gender";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(82, 310);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "Address";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(55, 142);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 15);
            this.label9.TabIndex = 8;
            this.label9.Text = "Date_of_Birth";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(106, 233);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 15);
            this.label10.TabIndex = 9;
            this.label10.Text = "Date";
            // 
            // r_date
            // 
            this.r_date.CustomFormat = "yyyy-MM-dd";
            this.r_date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.r_date.Location = new System.Drawing.Point(155, 229);
            this.r_date.Name = "r_date";
            this.r_date.Size = new System.Drawing.Size(132, 22);
            this.r_date.TabIndex = 10;
            // 
            // r_dob
            // 
            this.r_dob.CustomFormat = "yyyy-MM-dd";
            this.r_dob.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.r_dob.Location = new System.Drawing.Point(155, 139);
            this.r_dob.Name = "r_dob";
            this.r_dob.Size = new System.Drawing.Size(132, 22);
            this.r_dob.TabIndex = 11;
            // 
            // r_female
            // 
            this.r_female.AutoSize = true;
            this.r_female.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r_female.Location = new System.Drawing.Point(217, 199);
            this.r_female.Name = "r_female";
            this.r_female.Size = new System.Drawing.Size(54, 16);
            this.r_female.TabIndex = 12;
            this.r_female.TabStop = true;
            this.r_female.Text = "Female";
            this.r_female.UseVisualStyleBackColor = true;
            this.r_female.CheckedChanged += new System.EventHandler(this.r_female_CheckedChanged);
            // 
            // r_male
            // 
            this.r_male.AutoSize = true;
            this.r_male.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r_male.Location = new System.Drawing.Point(164, 202);
            this.r_male.Name = "r_male";
            this.r_male.Size = new System.Drawing.Size(44, 16);
            this.r_male.TabIndex = 13;
            this.r_male.TabStop = true;
            this.r_male.Text = "Male";
            this.r_male.UseVisualStyleBackColor = true;
            this.r_male.CheckedChanged += new System.EventHandler(this.r_male_CheckedChanged);
            // 
            // r_firstName
            // 
            this.r_firstName.Location = new System.Drawing.Point(155, 74);
            this.r_firstName.Name = "r_firstName";
            this.r_firstName.Size = new System.Drawing.Size(132, 22);
            this.r_firstName.TabIndex = 15;
            // 
            // r_lastName
            // 
            this.r_lastName.Location = new System.Drawing.Point(155, 104);
            this.r_lastName.Name = "r_lastName";
            this.r_lastName.Size = new System.Drawing.Size(132, 22);
            this.r_lastName.TabIndex = 16;
            // 
            // r_contact
            // 
            this.r_contact.Location = new System.Drawing.Point(155, 171);
            this.r_contact.Name = "r_contact";
            this.r_contact.Size = new System.Drawing.Size(132, 22);
            this.r_contact.TabIndex = 17;
            // 
            // r_booking
            // 
            this.r_booking.Location = new System.Drawing.Point(155, 260);
            this.r_booking.Multiline = true;
            this.r_booking.Name = "r_booking";
            this.r_booking.Size = new System.Drawing.Size(132, 41);
            this.r_booking.TabIndex = 18;
            // 
            // r_address
            // 
            this.r_address.Location = new System.Drawing.Point(155, 307);
            this.r_address.Name = "r_address";
            this.r_address.Size = new System.Drawing.Size(132, 22);
            this.r_address.TabIndex = 19;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Promethean Chrome", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(3, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(405, 20);
            this.label11.TabIndex = 21;
            this.label11.Text = "MATCH OFFICIALS DETAILS";
            // 
            // r_venueid
            // 
            this.r_venueid.Location = new System.Drawing.Point(156, 336);
            this.r_venueid.Name = "r_venueid";
            this.r_venueid.Size = new System.Drawing.Size(132, 22);
            this.r_venueid.TabIndex = 23;
            this.r_venueid.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(85, 342);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(62, 15);
            this.label12.TabIndex = 22;
            this.label12.Text = "VenueID";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // r_Save
            // 
            this.r_Save.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.r_Save.Font = new System.Drawing.Font("Promethean Chrome Italic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.r_Save.Location = new System.Drawing.Point(180, 366);
            this.r_Save.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.r_Save.Name = "r_Save";
            this.r_Save.Size = new System.Drawing.Size(75, 23);
            this.r_Save.TabIndex = 24;
            this.r_Save.Text = "Save";
            this.r_Save.UseVisualStyleBackColor = false;
            this.r_Save.Click += new System.EventHandler(this.r_Save_Click);
            // 
            // r_delete
            // 
            this.r_delete.Font = new System.Drawing.Font("Promethean Chrome Italic", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r_delete.Location = new System.Drawing.Point(261, 366);
            this.r_delete.Name = "r_delete";
            this.r_delete.Size = new System.Drawing.Size(75, 23);
            this.r_delete.TabIndex = 26;
            this.r_delete.Text = "Delete";
            this.r_delete.UseVisualStyleBackColor = true;
            this.r_delete.Click += new System.EventHandler(this.r_delete_Click);
            // 
            // r_update
            // 
            this.r_update.Font = new System.Drawing.Font("Promethean Chrome Italic", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r_update.Location = new System.Drawing.Point(99, 366);
            this.r_update.Name = "r_update";
            this.r_update.Size = new System.Drawing.Size(75, 23);
            this.r_update.TabIndex = 25;
            this.r_update.Text = "Update";
            this.r_update.UseVisualStyleBackColor = true;
            this.r_update.Click += new System.EventHandler(this.r_update_Click);
            // 
            // r_refreeid
            // 
            this.r_refreeid.Location = new System.Drawing.Point(155, 46);
            this.r_refreeid.Name = "r_refreeid";
            this.r_refreeid.Size = new System.Drawing.Size(132, 22);
            this.r_refreeid.TabIndex = 28;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(71, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 15);
            this.label7.TabIndex = 27;
            this.label7.Text = "RefreeID";
            // 
            // Refree_information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(420, 449);
            this.Controls.Add(this.r_refreeid);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.r_delete);
            this.Controls.Add(this.r_update);
            this.Controls.Add(this.r_Save);
            this.Controls.Add(this.r_venueid);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.r_address);
            this.Controls.Add(this.r_booking);
            this.Controls.Add(this.r_contact);
            this.Controls.Add(this.r_lastName);
            this.Controls.Add(this.r_firstName);
            this.Controls.Add(this.r_male);
            this.Controls.Add(this.r_female);
            this.Controls.Add(this.r_dob);
            this.Controls.Add(this.r_date);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Lucida Bright", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Refree_information";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Refree_information";
            this.Load += new System.EventHandler(this.Refree_information_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker r_date;
        private System.Windows.Forms.DateTimePicker r_dob;
        private System.Windows.Forms.RadioButton r_female;
        private System.Windows.Forms.RadioButton r_male;
        private System.Windows.Forms.TextBox r_firstName;
        private System.Windows.Forms.TextBox r_lastName;
        private System.Windows.Forms.TextBox r_contact;
        private System.Windows.Forms.TextBox r_booking;
        private System.Windows.Forms.TextBox r_address;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox r_venueid;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button r_Save;
        private System.Windows.Forms.Button r_delete;
        private System.Windows.Forms.Button r_update;
        private System.Windows.Forms.TextBox r_refreeid;
        private System.Windows.Forms.Label label7;
    }
}