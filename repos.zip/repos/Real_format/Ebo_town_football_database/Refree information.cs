﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ebo_town_football_Database
{
    public partial class Refree_information : Form
    {
        String Gender;
        public Refree_information()
        {
            InitializeComponent();
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void r_Save_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into Refree_Information(RefreeID, First_Name, Last_Name, Date_of_Birth ,Contact, Gender, Date ,Booking ,Address , VenueID) values" +
                    " ('" + r_refreeid.Text + "','" + r_firstName.Text + "','" + r_lastName.Text + "','" + r_dob.Text + "','" + r_contact.Text + "','" + Gender + "','" + r_date.Text + "','" + r_booking + "','" + r_address.Text + "','" + r_venueid.Text + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully saved record for Refree_Information  " +  " First_name " + r_firstName.Text);
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist "  + ex.Message);
            }
        }

        private void r_male_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "male";
        }

        private void r_female_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "female";
        }

        private void Refree_information_Load(object sender, EventArgs e)
        {

        }

        private void r_update_Click(object sender, EventArgs e)
        {

            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "update Refree_Information set RefreeID ='" + r_refreeid.Text + "',First_Name=" +
                    "'" + r_firstName.Text + "',Last_Name='" + r_lastName.Text + "',Date_of_Birth='" + r_dob.Text + "',Contact='" +
                    r_contact.Text + "' ,Gender ='" +Gender + "' ,Date='" +r_date.Text + "' ,Booking ='" + r_booking.Text + "" +
                    "',Address ='" + r_address.Text + "', VenueID ='" + r_venueid.Text + "' where RefreeID='" +r_refreeid.Text +
                    "'  ";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully Updates record for Refree_Information  " + " RefreeID " + r_refreeid.Text);
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Updates check it might exist " + ex.Message);
            }
        }

        private void r_delete_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=Ebo_town_football_database;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "delete  from Refree_Information where  RefreeID = '" + r_refreeid.Text + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully delete record for Refree_Information  " + "RefreeID" + r_refreeid.Text);
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be delete check it might exist " + ex.Message);
            }
        }
    }
    }
    
    

