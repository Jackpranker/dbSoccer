﻿namespace Ebo_town_football_Database
{
    partial class Team_Information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.t_name = new System.Windows.Forms.TextBox();
            this.t_contact = new System.Windows.Forms.TextBox();
            this.t_est = new System.Windows.Forms.TextBox();
            this.t_address = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.t_Save = new System.Windows.Forms.Button();
            this.t_delete = new System.Windows.Forms.Button();
            this.t_update = new System.Windows.Forms.Button();
            this.t_teamid = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(54, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Establishment";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(54, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Address";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(54, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Contact";
            // 
            // t_name
            // 
            this.t_name.Location = new System.Drawing.Point(121, 76);
            this.t_name.Name = "t_name";
            this.t_name.Size = new System.Drawing.Size(140, 22);
            this.t_name.TabIndex = 6;
            // 
            // t_contact
            // 
            this.t_contact.Location = new System.Drawing.Point(121, 132);
            this.t_contact.Name = "t_contact";
            this.t_contact.Size = new System.Drawing.Size(140, 22);
            this.t_contact.TabIndex = 7;
            // 
            // t_est
            // 
            this.t_est.Location = new System.Drawing.Point(158, 160);
            this.t_est.Name = "t_est";
            this.t_est.Size = new System.Drawing.Size(103, 22);
            this.t_est.TabIndex = 8;
            // 
            // t_address
            // 
            this.t_address.Location = new System.Drawing.Point(121, 104);
            this.t_address.Name = "t_address";
            this.t_address.Size = new System.Drawing.Size(140, 22);
            this.t_address.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Promethean Chrome Italic", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(65, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(246, 23);
            this.label6.TabIndex = 10;
            this.label6.Text = "TEAM PROFILE";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // t_Save
            // 
            this.t_Save.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.t_Save.Font = new System.Drawing.Font("Promethean Chrome Italic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.t_Save.Location = new System.Drawing.Point(140, 198);
            this.t_Save.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.t_Save.Name = "t_Save";
            this.t_Save.Size = new System.Drawing.Size(75, 23);
            this.t_Save.TabIndex = 12;
            this.t_Save.Text = "Save";
            this.t_Save.UseVisualStyleBackColor = false;
            this.t_Save.Click += new System.EventHandler(this.t_Save_Click);
            // 
            // t_delete
            // 
            this.t_delete.Font = new System.Drawing.Font("Promethean Chrome Italic", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t_delete.Location = new System.Drawing.Point(221, 198);
            this.t_delete.Name = "t_delete";
            this.t_delete.Size = new System.Drawing.Size(75, 23);
            this.t_delete.TabIndex = 15;
            this.t_delete.Text = "Delete";
            this.t_delete.UseVisualStyleBackColor = true;
            this.t_delete.Click += new System.EventHandler(this.t_delete_Click);
            // 
            // t_update
            // 
            this.t_update.Font = new System.Drawing.Font("Promethean Chrome Italic", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t_update.Location = new System.Drawing.Point(59, 198);
            this.t_update.Name = "t_update";
            this.t_update.Size = new System.Drawing.Size(75, 23);
            this.t_update.TabIndex = 14;
            this.t_update.Text = "Update";
            this.t_update.UseVisualStyleBackColor = true;
            this.t_update.Click += new System.EventHandler(this.t_update_Click);
            // 
            // t_teamid
            // 
            this.t_teamid.Location = new System.Drawing.Point(121, 48);
            this.t_teamid.Name = "t_teamid";
            this.t_teamid.Size = new System.Drawing.Size(140, 22);
            this.t_teamid.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 15);
            this.label1.TabIndex = 16;
            this.label1.Text = "TeamID";
            // 
            // Team_Information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(327, 257);
            this.Controls.Add(this.t_teamid);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.t_delete);
            this.Controls.Add(this.t_update);
            this.Controls.Add(this.t_Save);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.t_address);
            this.Controls.Add(this.t_est);
            this.Controls.Add(this.t_contact);
            this.Controls.Add(this.t_name);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Lucida Bright", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Team_Information";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Team_Information";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox t_name;
        private System.Windows.Forms.TextBox t_contact;
        private System.Windows.Forms.TextBox t_est;
        private System.Windows.Forms.TextBox t_address;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button t_Save;
        private System.Windows.Forms.Button t_delete;
        private System.Windows.Forms.Button t_update;
        private System.Windows.Forms.TextBox t_teamid;
        private System.Windows.Forms.Label label1;
    }
}