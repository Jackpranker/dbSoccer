﻿namespace Ebo_town_football_Database
{
    partial class Venue_information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.v_name = new System.Windows.Forms.TextBox();
            this.v_time = new System.Windows.Forms.TextBox();
            this.v_date = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.v_Save = new System.Windows.Forms.Button();
            this.v_delete = new System.Windows.Forms.Button();
            this.v_update = new System.Windows.Forms.Button();
            this.v_venueid = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(84, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Time";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(91, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Date";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(84, 79);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Name";
            // 
            // v_name
            // 
            this.v_name.Location = new System.Drawing.Point(134, 76);
            this.v_name.Name = "v_name";
            this.v_name.Size = new System.Drawing.Size(132, 22);
            this.v_name.TabIndex = 6;
            // 
            // v_time
            // 
            this.v_time.Location = new System.Drawing.Point(134, 106);
            this.v_time.Name = "v_time";
            this.v_time.Size = new System.Drawing.Size(132, 22);
            this.v_time.TabIndex = 7;
            // 
            // v_date
            // 
            this.v_date.CustomFormat = "yyyy-MM-dd";
            this.v_date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.v_date.Location = new System.Drawing.Point(134, 138);
            this.v_date.Name = "v_date";
            this.v_date.Size = new System.Drawing.Size(132, 22);
            this.v_date.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Promethean Chrome Italic", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(104, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(182, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "VENUE INFO";
            // 
            // v_Save
            // 
            this.v_Save.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.v_Save.Font = new System.Drawing.Font("Promethean Chrome Italic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.v_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.v_Save.Location = new System.Drawing.Point(160, 165);
            this.v_Save.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.v_Save.Name = "v_Save";
            this.v_Save.Size = new System.Drawing.Size(75, 23);
            this.v_Save.TabIndex = 12;
            this.v_Save.Text = "Save";
            this.v_Save.UseVisualStyleBackColor = false;
            this.v_Save.Click += new System.EventHandler(this.v_Save_Click);
            // 
            // v_delete
            // 
            this.v_delete.Font = new System.Drawing.Font("Promethean Chrome Italic", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.v_delete.Location = new System.Drawing.Point(241, 165);
            this.v_delete.Name = "v_delete";
            this.v_delete.Size = new System.Drawing.Size(75, 23);
            this.v_delete.TabIndex = 15;
            this.v_delete.Text = "Delete";
            this.v_delete.UseVisualStyleBackColor = true;
            this.v_delete.Click += new System.EventHandler(this.v_delete_Click);
            // 
            // v_update
            // 
            this.v_update.Font = new System.Drawing.Font("Promethean Chrome Italic", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.v_update.Location = new System.Drawing.Point(79, 165);
            this.v_update.Name = "v_update";
            this.v_update.Size = new System.Drawing.Size(75, 23);
            this.v_update.TabIndex = 14;
            this.v_update.Text = "Update";
            this.v_update.UseVisualStyleBackColor = true;
            this.v_update.Click += new System.EventHandler(this.v_update_Click);
            // 
            // v_venueid
            // 
            this.v_venueid.Location = new System.Drawing.Point(134, 48);
            this.v_venueid.Name = "v_venueid";
            this.v_venueid.Size = new System.Drawing.Size(132, 22);
            this.v_venueid.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(66, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 15);
            this.label1.TabIndex = 16;
            this.label1.Text = "VenueID";
            // 
            // Venue_information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(357, 253);
            this.Controls.Add(this.v_venueid);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.v_delete);
            this.Controls.Add(this.v_update);
            this.Controls.Add(this.v_Save);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.v_date);
            this.Controls.Add(this.v_time);
            this.Controls.Add(this.v_name);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Lucida Bright", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Venue_information";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Venue_information";
            this.Load += new System.EventHandler(this.Venue_information_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox v_name;
        private System.Windows.Forms.TextBox v_time;
        private System.Windows.Forms.DateTimePicker v_date;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button v_Save;
        private System.Windows.Forms.Button v_delete;
        private System.Windows.Forms.Button v_update;
        private System.Windows.Forms.TextBox v_venueid;
        private System.Windows.Forms.Label label1;
    }
}