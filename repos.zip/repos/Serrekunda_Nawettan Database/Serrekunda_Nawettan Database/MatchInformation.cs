﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Serrekunda_Nawettan_Database
{
    public partial class MatchInformation : Form
    {
        SqlDataAdapter adapt;
        DataTable dt;
        public MatchInformation()
        {
            InitializeComponent();
        }

        private void g_update_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=SerrekundaNawettanDatabse;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "update MatchInformation set ID ='" + id.Text + "', Fixture='" + f.Text + "',Match1='" + m1.Text + "',match2='" + m2.Text + "' where ID='" + id.Text + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully Updates record for Information  " + " ID " + id.Text);
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Updates check it might exist " + ex.Message);
            }
        }

        private void g_Save_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=SerrekundaNawettanDatabse;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into MatchInformation(ID,Fixture,Match1,Match2) values" +
                    "('" + id.Text + "','" + f.Text + "','" + m1.Text + "','" + m2.Text + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully saved record for Information  ");
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " + ex.Message);
            }
        }

        private void g_delete_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=SerrekundaNawettanDatabse;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "delete  from MatchInformation where  ID = '" + id.Text + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully delete record for Information  " + "ID" + id.Text);
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be delete check it might exist " + ex.Message);
            }
        }

        private void MatchInformation_Load(object sender, EventArgs e)
        {
            try
            {

                string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=SerrekundaNawettanDatabse;Integrated Security=True";
                SqlConnection conn = new SqlConnection();
                conn = new SqlConnection(cs);
                conn.Open();
                //put the name of the table
                adapt = new SqlDataAdapter("select * from MatchInformation", conn);
                dt = new DataTable();
                adapt.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Data view" + ex.Message);
                //conn.Close();

            }
        }

        private void s_TextChanged(object sender, EventArgs e)
        {
            string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=SerrekundaNawettanDatabse;Integrated Security=True";
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection(cs);
            conn = new SqlConnection(cs);
            conn.Open();
            adapt = new SqlDataAdapter("select * from MatchInformation where ID like '" + s.Text + "%'", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }
    }
}
