﻿
namespace Serrekunda_Nawettan_Database
{
    partial class ProfileInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProfileInformation));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.p = new System.Windows.Forms.TextBox();
            this.t = new System.Windows.Forms.TextBox();
            this.m = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.s = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.id = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.g_delete = new System.Windows.Forms.Button();
            this.g_update = new System.Windows.Forms.Button();
            this.g_Save = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Teams";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Players";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(44, 158);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Media";
            // 
            // p
            // 
            this.p.Location = new System.Drawing.Point(119, 120);
            this.p.Name = "p";
            this.p.Size = new System.Drawing.Size(100, 20);
            this.p.TabIndex = 2;
            this.p.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // t
            // 
            this.t.Location = new System.Drawing.Point(119, 87);
            this.t.Name = "t";
            this.t.Size = new System.Drawing.Size(100, 20);
            this.t.TabIndex = 2;
            // 
            // m
            // 
            this.m.Location = new System.Drawing.Point(119, 155);
            this.m.Name = "m";
            this.m.Size = new System.Drawing.Size(100, 20);
            this.m.TabIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(256, 54);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(424, 172);
            this.dataGridView1.TabIndex = 3;
            // 
            // s
            // 
            this.s.Location = new System.Drawing.Point(150, 206);
            this.s.Name = "s";
            this.s.Size = new System.Drawing.Size(100, 20);
            this.s.TabIndex = 2;
            this.s.TextChanged += new System.EventHandler(this.s_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(102, 209);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Search";
            // 
            // id
            // 
            this.id.Location = new System.Drawing.Point(119, 61);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(100, 20);
            this.id.TabIndex = 16;
            this.id.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(39, 64);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "ID";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // g_delete
            // 
            this.g_delete.BackColor = System.Drawing.Color.Red;
            this.g_delete.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.g_delete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.g_delete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.g_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g_delete.ForeColor = System.Drawing.Color.White;
            this.g_delete.Location = new System.Drawing.Point(431, 232);
            this.g_delete.Name = "g_delete";
            this.g_delete.Size = new System.Drawing.Size(59, 30);
            this.g_delete.TabIndex = 19;
            this.g_delete.Text = "Delete";
            this.g_delete.UseVisualStyleBackColor = false;
            this.g_delete.Click += new System.EventHandler(this.g_delete_Click);
            // 
            // g_update
            // 
            this.g_update.BackColor = System.Drawing.Color.Blue;
            this.g_update.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.g_update.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.g_update.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.g_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g_update.ForeColor = System.Drawing.Color.White;
            this.g_update.Location = new System.Drawing.Point(290, 232);
            this.g_update.Name = "g_update";
            this.g_update.Size = new System.Drawing.Size(65, 30);
            this.g_update.TabIndex = 18;
            this.g_update.Text = "Update";
            this.g_update.UseVisualStyleBackColor = false;
            this.g_update.Click += new System.EventHandler(this.g_update_Click);
            // 
            // g_Save
            // 
            this.g_Save.BackColor = System.Drawing.Color.Lime;
            this.g_Save.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.g_Save.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.g_Save.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.g_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.g_Save.Location = new System.Drawing.Point(361, 232);
            this.g_Save.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.g_Save.Name = "g_Save";
            this.g_Save.Size = new System.Drawing.Size(64, 30);
            this.g_Save.TabIndex = 17;
            this.g_Save.Text = "Save";
            this.g_Save.UseVisualStyleBackColor = false;
            this.g_Save.Click += new System.EventHandler(this.g_Save_Click);
            // 
            // ProfileInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.g_delete);
            this.Controls.Add(this.g_update);
            this.Controls.Add(this.g_Save);
            this.Controls.Add(this.id);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.t);
            this.Controls.Add(this.s);
            this.Controls.Add(this.m);
            this.Controls.Add(this.p);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ProfileInformation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProfileInformation";
            this.Load += new System.EventHandler(this.ProfileInformation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox p;
        private System.Windows.Forms.TextBox t;
        private System.Windows.Forms.TextBox m;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox s;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox id;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button g_delete;
        private System.Windows.Forms.Button g_update;
        private System.Windows.Forms.Button g_Save;
    }
}

