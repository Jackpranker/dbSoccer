﻿
namespace Serrekunda_Nawettan_Database
{
    partial class SerrekundaNawettan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SerrekundaNawettan));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.matchInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.matchInformationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mediaInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mediaInformationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.profileInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.profileInformationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.resultsInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resultsInformationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.standingInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.standingInformationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.matchInformationToolStripMenuItem,
            this.mediaInformationToolStripMenuItem,
            this.profileInformationToolStripMenuItem,
            this.resultsInformationToolStripMenuItem,
            this.standingInformationToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(869, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 382);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(869, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel.Text = "Status";
            // 
            // matchInformationToolStripMenuItem
            // 
            this.matchInformationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.matchInformationToolStripMenuItem1});
            this.matchInformationToolStripMenuItem.Name = "matchInformationToolStripMenuItem";
            this.matchInformationToolStripMenuItem.Size = new System.Drawing.Size(119, 20);
            this.matchInformationToolStripMenuItem.Text = "Match Information";
            // 
            // matchInformationToolStripMenuItem1
            // 
            this.matchInformationToolStripMenuItem1.Name = "matchInformationToolStripMenuItem1";
            this.matchInformationToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.matchInformationToolStripMenuItem1.Text = "Match Information";
            this.matchInformationToolStripMenuItem1.Click += new System.EventHandler(this.matchInformationToolStripMenuItem1_Click);
            // 
            // mediaInformationToolStripMenuItem
            // 
            this.mediaInformationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mediaInformationToolStripMenuItem1});
            this.mediaInformationToolStripMenuItem.Name = "mediaInformationToolStripMenuItem";
            this.mediaInformationToolStripMenuItem.Size = new System.Drawing.Size(118, 20);
            this.mediaInformationToolStripMenuItem.Text = "Media Information";
            this.mediaInformationToolStripMenuItem.Click += new System.EventHandler(this.mediaInformationToolStripMenuItem_Click);
            // 
            // mediaInformationToolStripMenuItem1
            // 
            this.mediaInformationToolStripMenuItem1.Name = "mediaInformationToolStripMenuItem1";
            this.mediaInformationToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.mediaInformationToolStripMenuItem1.Text = "Media Information";
            this.mediaInformationToolStripMenuItem1.Click += new System.EventHandler(this.mediaInformationToolStripMenuItem1_Click);
            // 
            // profileInformationToolStripMenuItem
            // 
            this.profileInformationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.profileInformationToolStripMenuItem1});
            this.profileInformationToolStripMenuItem.Name = "profileInformationToolStripMenuItem";
            this.profileInformationToolStripMenuItem.Size = new System.Drawing.Size(119, 20);
            this.profileInformationToolStripMenuItem.Text = "Profile Information";
            // 
            // profileInformationToolStripMenuItem1
            // 
            this.profileInformationToolStripMenuItem1.Name = "profileInformationToolStripMenuItem1";
            this.profileInformationToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.profileInformationToolStripMenuItem1.Text = "Profile Information";
            this.profileInformationToolStripMenuItem1.Click += new System.EventHandler(this.profileInformationToolStripMenuItem1_Click);
            // 
            // resultsInformationToolStripMenuItem
            // 
            this.resultsInformationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resultsInformationToolStripMenuItem1});
            this.resultsInformationToolStripMenuItem.Name = "resultsInformationToolStripMenuItem";
            this.resultsInformationToolStripMenuItem.Size = new System.Drawing.Size(122, 20);
            this.resultsInformationToolStripMenuItem.Text = "Results Information";
            // 
            // resultsInformationToolStripMenuItem1
            // 
            this.resultsInformationToolStripMenuItem1.Name = "resultsInformationToolStripMenuItem1";
            this.resultsInformationToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.resultsInformationToolStripMenuItem1.Text = "Results Information";
            this.resultsInformationToolStripMenuItem1.Click += new System.EventHandler(this.resultsInformationToolStripMenuItem1_Click);
            // 
            // standingInformationToolStripMenuItem
            // 
            this.standingInformationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.standingInformationToolStripMenuItem1});
            this.standingInformationToolStripMenuItem.Name = "standingInformationToolStripMenuItem";
            this.standingInformationToolStripMenuItem.Size = new System.Drawing.Size(132, 20);
            this.standingInformationToolStripMenuItem.Text = "Standing Information";
            // 
            // standingInformationToolStripMenuItem1
            // 
            this.standingInformationToolStripMenuItem1.Name = "standingInformationToolStripMenuItem1";
            this.standingInformationToolStripMenuItem1.Size = new System.Drawing.Size(187, 22);
            this.standingInformationToolStripMenuItem1.Text = "Standing Information";
            this.standingInformationToolStripMenuItem1.Click += new System.EventHandler(this.standingInformationToolStripMenuItem1_Click);
            // 
            // SerrekundaNawettan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(869, 404);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "SerrekundaNawettan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Serrekunda Nawettan";
            this.Load += new System.EventHandler(this.SerrekundaNawettan_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem matchInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem matchInformationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mediaInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mediaInformationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem profileInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem profileInformationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem resultsInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resultsInformationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem standingInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem standingInformationToolStripMenuItem1;
    }
}



