﻿
namespace Serrekunda_Nawettan_Database
{
    partial class StandingInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StandingInformation));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tb = new System.Windows.Forms.TextBox();
            this.s = new System.Windows.Forms.TextBox();
            this.ts = new System.Windows.Forms.TextBox();
            this.lg = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ta = new System.Windows.Forms.TextBox();
            this.id = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.g_delete = new System.Windows.Forms.Button();
            this.g_update = new System.Windows.Forms.Button();
            this.g_Save = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(254, 38);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(545, 172);
            this.dataGridView1.TabIndex = 12;
            // 
            // tb
            // 
            this.tb.Location = new System.Drawing.Point(114, 59);
            this.tb.Name = "tb";
            this.tb.Size = new System.Drawing.Size(100, 20);
            this.tb.TabIndex = 8;
            // 
            // s
            // 
            this.s.Location = new System.Drawing.Point(148, 190);
            this.s.Name = "s";
            this.s.Size = new System.Drawing.Size(100, 20);
            this.s.TabIndex = 9;
            this.s.TextChanged += new System.EventHandler(this.s_TextChanged);
            // 
            // ts
            // 
            this.ts.Location = new System.Drawing.Point(114, 127);
            this.ts.Name = "ts";
            this.ts.Size = new System.Drawing.Size(100, 20);
            this.ts.TabIndex = 10;
            // 
            // lg
            // 
            this.lg.Location = new System.Drawing.Point(114, 92);
            this.lg.Name = "lg";
            this.lg.Size = new System.Drawing.Size(100, 20);
            this.lg.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(100, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Search";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(39, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "TopScorer";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Log";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Table";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(39, 156);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "TopAsssist";
            // 
            // ta
            // 
            this.ta.Location = new System.Drawing.Point(114, 153);
            this.ta.Name = "ta";
            this.ta.Size = new System.Drawing.Size(100, 20);
            this.ta.TabIndex = 10;
            // 
            // id
            // 
            this.id.Location = new System.Drawing.Point(114, 24);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(100, 20);
            this.id.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(18, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "ID";
            // 
            // g_delete
            // 
            this.g_delete.BackColor = System.Drawing.Color.Red;
            this.g_delete.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.g_delete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.g_delete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.g_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g_delete.ForeColor = System.Drawing.Color.White;
            this.g_delete.Location = new System.Drawing.Point(456, 216);
            this.g_delete.Name = "g_delete";
            this.g_delete.Size = new System.Drawing.Size(59, 30);
            this.g_delete.TabIndex = 19;
            this.g_delete.Text = "Delete";
            this.g_delete.UseVisualStyleBackColor = false;
            this.g_delete.Click += new System.EventHandler(this.g_delete_Click);
            // 
            // g_update
            // 
            this.g_update.BackColor = System.Drawing.Color.Blue;
            this.g_update.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.g_update.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.g_update.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.g_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g_update.ForeColor = System.Drawing.Color.White;
            this.g_update.Location = new System.Drawing.Point(315, 216);
            this.g_update.Name = "g_update";
            this.g_update.Size = new System.Drawing.Size(65, 30);
            this.g_update.TabIndex = 18;
            this.g_update.Text = "Update";
            this.g_update.UseVisualStyleBackColor = false;
            this.g_update.Click += new System.EventHandler(this.g_update_Click);
            // 
            // g_Save
            // 
            this.g_Save.BackColor = System.Drawing.Color.Lime;
            this.g_Save.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.g_Save.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.g_Save.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.g_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.g_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.g_Save.Location = new System.Drawing.Point(386, 216);
            this.g_Save.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.g_Save.Name = "g_Save";
            this.g_Save.Size = new System.Drawing.Size(64, 30);
            this.g_Save.TabIndex = 17;
            this.g_Save.Text = "Save";
            this.g_Save.UseVisualStyleBackColor = false;
            this.g_Save.Click += new System.EventHandler(this.g_Save_Click);
            // 
            // StandingInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.g_delete);
            this.Controls.Add(this.g_update);
            this.Controls.Add(this.g_Save);
            this.Controls.Add(this.id);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.tb);
            this.Controls.Add(this.s);
            this.Controls.Add(this.ta);
            this.Controls.Add(this.ts);
            this.Controls.Add(this.lg);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "StandingInformation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StandingInformation";
            this.Load += new System.EventHandler(this.StandingInformation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox tb;
        private System.Windows.Forms.TextBox s;
        private System.Windows.Forms.TextBox ts;
        private System.Windows.Forms.TextBox lg;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox ta;
        private System.Windows.Forms.TextBox id;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button g_delete;
        private System.Windows.Forms.Button g_update;
        private System.Windows.Forms.Button g_Save;
    }
}