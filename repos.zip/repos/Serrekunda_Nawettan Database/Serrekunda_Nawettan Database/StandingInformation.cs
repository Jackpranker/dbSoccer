﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Serrekunda_Nawettan_Database
{
    public partial class StandingInformation : Form
    {
        SqlDataAdapter adapt;
        DataTable dt;
        public StandingInformation()
        {
            InitializeComponent();
        }

        private void g_update_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=SerrekundaNawettanDatabse;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "update StandingInformation set ID ='" + id.Text + "', Tablee='" + tb.Text + "',Logg='" + lg.Text + "',TopScorer='" + ts.Text + "',TopAssist='" + ts.Text + "' where ID='" + id.Text + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully Updates record for Information  " + " ID " + id.Text);
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Updates check it might exist " + ex.Message);
            }
        }

        private void g_Save_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=SerrekundaNawettanDatabse;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into StandingInformation(ID,Tablee,Logg,TopScorer,TopAssist) values" +
                    "('" + id.Text + "','" + tb.Text + "','" + lg.Text + "','" + ts.Text + "'," +
                    "'" + ta.Text + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully saved record for Information  " );
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " + ex.Message);
            }
        }

        private void g_delete_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=JP\\SQLEXPRESS;Initial Catalog=SerrekundaNawettanDatabse;Integrated Security=True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = cmd.CommandText = "delete  from StandingInformation where  ID = '" + id.Text + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully delete record for Information  " + "ID" + id.Text);
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be delete check it might exist " + ex.Message);
            }
        }

        private void StandingInformation_Load(object sender, EventArgs e)
        {
            try
            {

                string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=SerrekundaNawettanDatabse;Integrated Security=True";
                SqlConnection conn = new SqlConnection();
                conn = new SqlConnection(cs);
                conn.Open();
                //put the name of the table
                adapt = new SqlDataAdapter("select * from StandingInformation", conn);
                dt = new DataTable();
                adapt.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Data view" + ex.Message);
                //conn.Close();

            }
        }

        private void s_TextChanged(object sender, EventArgs e)
        {
            string cs = "Data Source=JP\\SQLEXPRESS;Initial Catalog=SerrekundaNawettanDatabse;Integrated Security=True";
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection(cs);
            conn = new SqlConnection(cs);
            conn.Open();
            adapt = new SqlDataAdapter("select * from StandingInformation where ID like '" + s.Text + "%'", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }
    }
}
