﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sms
{
    public partial class Course_information : Form
    {
        public Course_information()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                String connectionString = "Data Source = JACKSWANCEE\\SQLEXPRESS; Initial Catalog = Sms; Integrated Security = True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into Course_Information(CourseID,Course_Name,Course_Discription) values ('" + c_courseid.Text + "', '" + c_name.Text + "','" + c_discription.Text + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully saved record for Course_Information" + c_courseid.Text + "Name " + c_name.Text);
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " +c_courseid.Text+ ex.Message);
            }
        }

        private void Course_information_Load(object sender, EventArgs e)
        {

        }
    }
}
