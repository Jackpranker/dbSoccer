﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sms
{
    public partial class Department_information : Form
    {
        public Department_information()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                String connectionString = "Data Source = JACKSWANCEE\\SQLEXPRESS; Initial Catalog = Sms; Integrated Security = True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into Department_Information(DepartmentID,Name,Discription,LectureID) values ('" + d_departmentid.Text + "', '" + d_name.Text + "','" + d_discription.Text + "', '" + d_lectureid.Text + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully saved record for Department_Information" + d_departmentid.Text + "Name " +d_name.Text);
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " + d_departmentid.Text + ex.Message);
            }
        }
    }
    }

