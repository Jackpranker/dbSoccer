﻿namespace sms
{
    partial class Grades_information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.g_gradesid = new System.Windows.Forms.TextBox();
            this.g_score = new System.Windows.Forms.TextBox();
            this.g_term = new System.Windows.Forms.TextBox();
            this.g_studentid = new System.Windows.Forms.TextBox();
            this.g_year = new System.Windows.Forms.TextBox();
            this.g_lectureid = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.g_remarks = new System.Windows.Forms.TextBox();
            this.Register = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "GradesID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Score";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 171);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Term";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(37, 218);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "StudentD";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(35, 249);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "LectureID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(40, 151);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Year";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(26, 121);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Remarks";
            // 
            // g_gradesid
            // 
            this.g_gradesid.Location = new System.Drawing.Point(99, 35);
            this.g_gradesid.Name = "g_gradesid";
            this.g_gradesid.Size = new System.Drawing.Size(100, 20);
            this.g_gradesid.TabIndex = 8;
            // 
            // g_score
            // 
            this.g_score.Location = new System.Drawing.Point(99, 81);
            this.g_score.Name = "g_score";
            this.g_score.Size = new System.Drawing.Size(100, 20);
            this.g_score.TabIndex = 9;
            // 
            // g_term
            // 
            this.g_term.Location = new System.Drawing.Point(99, 170);
            this.g_term.Name = "g_term";
            this.g_term.Size = new System.Drawing.Size(100, 20);
            this.g_term.TabIndex = 10;
            this.g_term.TextChanged += new System.EventHandler(this.g_term_TextChanged);
            // 
            // g_studentid
            // 
            this.g_studentid.Location = new System.Drawing.Point(99, 211);
            this.g_studentid.Name = "g_studentid";
            this.g_studentid.Size = new System.Drawing.Size(100, 20);
            this.g_studentid.TabIndex = 11;
            // 
            // g_year
            // 
            this.g_year.Location = new System.Drawing.Point(99, 144);
            this.g_year.Name = "g_year";
            this.g_year.Size = new System.Drawing.Size(100, 20);
            this.g_year.TabIndex = 12;
            // 
            // g_lectureid
            // 
            this.g_lectureid.Location = new System.Drawing.Point(99, 246);
            this.g_lectureid.Name = "g_lectureid";
            this.g_lectureid.Size = new System.Drawing.Size(100, 20);
            this.g_lectureid.TabIndex = 13;
            // 
            // g_remarks
            // 
            this.g_remarks.Location = new System.Drawing.Point(99, 118);
            this.g_remarks.Name = "g_remarks";
            this.g_remarks.Size = new System.Drawing.Size(100, 20);
            this.g_remarks.TabIndex = 14;
            // 
            // Register
            // 
            this.Register.Location = new System.Drawing.Point(99, 303);
            this.Register.Name = "Register";
            this.Register.Size = new System.Drawing.Size(75, 23);
            this.Register.TabIndex = 15;
            this.Register.Text = "Register";
            this.Register.UseVisualStyleBackColor = true;
            this.Register.Click += new System.EventHandler(this.button1_Click);
            // 
            // Grades_information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(288, 450);
            this.Controls.Add(this.Register);
            this.Controls.Add(this.g_remarks);
            this.Controls.Add(this.g_lectureid);
            this.Controls.Add(this.g_year);
            this.Controls.Add(this.g_studentid);
            this.Controls.Add(this.g_term);
            this.Controls.Add(this.g_score);
            this.Controls.Add(this.g_gradesid);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Grades_information";
            this.Text = "Grades_information";
            this.Load += new System.EventHandler(this.Grades_information_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox g_gradesid;
        private System.Windows.Forms.TextBox g_score;
        private System.Windows.Forms.TextBox g_term;
        private System.Windows.Forms.TextBox g_studentid;
        private System.Windows.Forms.TextBox g_year;
        private System.Windows.Forms.TextBox g_lectureid;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox g_remarks;
        private System.Windows.Forms.Button Register;
    }
}