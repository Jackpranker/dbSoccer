﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sms
{
    public partial class Grades_information : Form
    {
        public Grades_information()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                String connectionString = "Data Source = JACKSWANCEE\\SQLEXPRESS; Initial Catalog = Sms; Integrated Security = True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into Grades_Information(GradesID,Score,Remarks,Academic_Year,Term,StudentID,LectureID) values ('" + g_gradesid.Text + "', '" + g_score.Text + "','" + g_remarks.Text + "', '" + g_year.Text + "','" + g_term.Text + "','" + g_studentid.Text + "','" + g_lectureid.Text + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully saved record for Grades_Information" + g_gradesid.Text + "Score " + g_score.Text);
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " +g_gradesid.Text + ex.Message);
            }
        }

        private void Grades_information_Load(object sender, EventArgs e)
        {

        }

        private void g_term_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }

