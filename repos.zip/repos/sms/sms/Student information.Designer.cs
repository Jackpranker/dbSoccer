﻿namespace sms
{
    partial class StudentInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.studenrtid = new System.Windows.Forms.Label();
            this.DepartmentID = new System.Windows.Forms.Label();
            this.first_name = new System.Windows.Forms.Label();
            this.Marital_status = new System.Windows.Forms.Label();
            this.last_name = new System.Windows.Forms.Label();
            this.Date = new System.Windows.Forms.Label();
            this.gender = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.Label();
            this.s_tel = new System.Windows.Forms.Label();
            this.sr_date = new System.Windows.Forms.Label();
            this.Male = new System.Windows.Forms.RadioButton();
            this.s_msM = new System.Windows.Forms.RadioButton();
            this.s_msS = new System.Windows.Forms.RadioButton();
            this.s_msD = new System.Windows.Forms.RadioButton();
            this.Female = new System.Windows.Forms.RadioButton();
            this.s_studentid = new System.Windows.Forms.TextBox();
            this.s_fname = new System.Windows.Forms.TextBox();
            this.s_lname = new System.Windows.Forms.TextBox();
            this.s_address = new System.Windows.Forms.TextBox();
            this.s_contact = new System.Windows.Forms.TextBox();
            this.s_departmentid = new System.Windows.Forms.TextBox();
            this.s_dob = new System.Windows.Forms.DateTimePicker();
            this.s_registrationDate = new System.Windows.Forms.DateTimePicker();
            this.Register = new System.Windows.Forms.Button();
            this.email = new System.Windows.Forms.Label();
            this.s_email = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // studenrtid
            // 
            this.studenrtid.AutoSize = true;
            this.studenrtid.Location = new System.Drawing.Point(26, 25);
            this.studenrtid.Name = "studenrtid";
            this.studenrtid.Size = new System.Drawing.Size(55, 13);
            this.studenrtid.TabIndex = 0;
            this.studenrtid.Text = "StudentID";
            // 
            // DepartmentID
            // 
            this.DepartmentID.AutoSize = true;
            this.DepartmentID.Location = new System.Drawing.Point(31, 312);
            this.DepartmentID.Name = "DepartmentID";
            this.DepartmentID.Size = new System.Drawing.Size(73, 13);
            this.DepartmentID.TabIndex = 1;
            this.DepartmentID.Text = "DepartmentID";
            // 
            // first_name
            // 
            this.first_name.AutoSize = true;
            this.first_name.Location = new System.Drawing.Point(26, 61);
            this.first_name.Name = "first_name";
            this.first_name.Size = new System.Drawing.Size(45, 13);
            this.first_name.TabIndex = 2;
            this.first_name.Text = "F_name";
            // 
            // Marital_status
            // 
            this.Marital_status.AutoSize = true;
            this.Marital_status.Location = new System.Drawing.Point(26, 268);
            this.Marital_status.Name = "Marital_status";
            this.Marital_status.Size = new System.Drawing.Size(74, 13);
            this.Marital_status.TabIndex = 3;
            this.Marital_status.Text = "Marital_Status";
            // 
            // last_name
            // 
            this.last_name.AutoSize = true;
            this.last_name.Location = new System.Drawing.Point(26, 97);
            this.last_name.Name = "last_name";
            this.last_name.Size = new System.Drawing.Size(47, 13);
            this.last_name.TabIndex = 4;
            this.last_name.Text = "L_Name";
            // 
            // Date
            // 
            this.Date.AutoSize = true;
            this.Date.Location = new System.Drawing.Point(26, 134);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(74, 13);
            this.Date.TabIndex = 5;
            this.Date.Text = "Date_Of_Birth";
            // 
            // gender
            // 
            this.gender.AutoSize = true;
            this.gender.Location = new System.Drawing.Point(40, 219);
            this.gender.Name = "gender";
            this.gender.Size = new System.Drawing.Size(42, 13);
            this.gender.TabIndex = 6;
            this.gender.Text = "Gender";
            // 
            // Address
            // 
            this.Address.AutoSize = true;
            this.Address.Location = new System.Drawing.Point(29, 157);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(45, 13);
            this.Address.TabIndex = 7;
            this.Address.Text = "Address";
            // 
            // s_tel
            // 
            this.s_tel.AutoSize = true;
            this.s_tel.Location = new System.Drawing.Point(29, 194);
            this.s_tel.Name = "s_tel";
            this.s_tel.Size = new System.Drawing.Size(44, 13);
            this.s_tel.TabIndex = 8;
            this.s_tel.Text = "Contact";
            // 
            // sr_date
            // 
            this.sr_date.AutoSize = true;
            this.sr_date.Location = new System.Drawing.Point(31, 348);
            this.sr_date.Name = "sr_date";
            this.sr_date.Size = new System.Drawing.Size(92, 13);
            this.sr_date.TabIndex = 9;
            this.sr_date.Text = "Registration_Date";
            // 
            // Male
            // 
            this.Male.AutoSize = true;
            this.Male.Location = new System.Drawing.Point(101, 217);
            this.Male.Name = "Male";
            this.Male.Size = new System.Drawing.Size(48, 17);
            this.Male.TabIndex = 10;
            this.Male.TabStop = true;
            this.Male.Text = "Male";
            this.Male.UseVisualStyleBackColor = true;
            this.Male.CheckedChanged += new System.EventHandler(this.s_genderM_CheckedChanged);
            // 
            // s_msM
            // 
            this.s_msM.AutoSize = true;
            this.s_msM.Location = new System.Drawing.Point(106, 268);
            this.s_msM.Name = "s_msM";
            this.s_msM.Size = new System.Drawing.Size(60, 17);
            this.s_msM.TabIndex = 11;
            this.s_msM.TabStop = true;
            this.s_msM.Text = "Married";
            this.s_msM.UseVisualStyleBackColor = true;
            this.s_msM.CheckedChanged += new System.EventHandler(this.s_msM_CheckedChanged);
            // 
            // s_msS
            // 
            this.s_msS.AutoSize = true;
            this.s_msS.Location = new System.Drawing.Point(172, 268);
            this.s_msS.Name = "s_msS";
            this.s_msS.Size = new System.Drawing.Size(54, 17);
            this.s_msS.TabIndex = 12;
            this.s_msS.TabStop = true;
            this.s_msS.Text = "Single";
            this.s_msS.UseVisualStyleBackColor = true;
            this.s_msS.CheckedChanged += new System.EventHandler(this.s_msS_CheckedChanged);
            // 
            // s_msD
            // 
            this.s_msD.AutoSize = true;
            this.s_msD.Location = new System.Drawing.Point(232, 266);
            this.s_msD.Name = "s_msD";
            this.s_msD.Size = new System.Drawing.Size(68, 17);
            this.s_msD.TabIndex = 13;
            this.s_msD.TabStop = true;
            this.s_msD.Text = "Divorced";
            this.s_msD.UseVisualStyleBackColor = true;
            this.s_msD.CheckedChanged += new System.EventHandler(this.s_msD_CheckedChanged);
            // 
            // Female
            // 
            this.Female.AutoSize = true;
            this.Female.Location = new System.Drawing.Point(172, 217);
            this.Female.Name = "Female";
            this.Female.Size = new System.Drawing.Size(59, 17);
            this.Female.TabIndex = 14;
            this.Female.TabStop = true;
            this.Female.Text = "Female";
            this.Female.UseVisualStyleBackColor = true;
            this.Female.CheckedChanged += new System.EventHandler(this.s_genderF_CheckedChanged);
            // 
            // s_studentid
            // 
            this.s_studentid.Location = new System.Drawing.Point(106, 18);
            this.s_studentid.Name = "s_studentid";
            this.s_studentid.Size = new System.Drawing.Size(141, 20);
            this.s_studentid.TabIndex = 15;
            // 
            // s_fname
            // 
            this.s_fname.Location = new System.Drawing.Point(106, 63);
            this.s_fname.Name = "s_fname";
            this.s_fname.Size = new System.Drawing.Size(141, 20);
            this.s_fname.TabIndex = 16;
            // 
            // s_lname
            // 
            this.s_lname.Location = new System.Drawing.Point(106, 94);
            this.s_lname.Name = "s_lname";
            this.s_lname.Size = new System.Drawing.Size(141, 20);
            this.s_lname.TabIndex = 17;
            // 
            // s_address
            // 
            this.s_address.Location = new System.Drawing.Point(106, 154);
            this.s_address.Name = "s_address";
            this.s_address.Size = new System.Drawing.Size(141, 20);
            this.s_address.TabIndex = 18;
            // 
            // s_contact
            // 
            this.s_contact.Location = new System.Drawing.Point(106, 191);
            this.s_contact.Name = "s_contact";
            this.s_contact.Size = new System.Drawing.Size(141, 20);
            this.s_contact.TabIndex = 19;
            // 
            // s_departmentid
            // 
            this.s_departmentid.Location = new System.Drawing.Point(106, 305);
            this.s_departmentid.Name = "s_departmentid";
            this.s_departmentid.Size = new System.Drawing.Size(141, 20);
            this.s_departmentid.TabIndex = 20;
            this.s_departmentid.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // s_dob
            // 
            this.s_dob.CustomFormat = "yyyy-MM-dd";
            this.s_dob.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.s_dob.Location = new System.Drawing.Point(106, 128);
            this.s_dob.Name = "s_dob";
            this.s_dob.Size = new System.Drawing.Size(141, 20);
            this.s_dob.TabIndex = 21;
            // 
            // s_registrationDate
            // 
            this.s_registrationDate.CustomFormat = "yyyy-MM-dd";
            this.s_registrationDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.s_registrationDate.Location = new System.Drawing.Point(132, 342);
            this.s_registrationDate.Name = "s_registrationDate";
            this.s_registrationDate.Size = new System.Drawing.Size(120, 20);
            this.s_registrationDate.TabIndex = 22;
            // 
            // Register
            // 
            this.Register.AutoSize = true;
            this.Register.Location = new System.Drawing.Point(132, 386);
            this.Register.Name = "Register";
            this.Register.Size = new System.Drawing.Size(75, 23);
            this.Register.TabIndex = 23;
            this.Register.Text = "Register";
            this.Register.UseVisualStyleBackColor = true;
            this.Register.Click += new System.EventHandler(this.Register_Click);
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Location = new System.Drawing.Point(40, 245);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(32, 13);
            this.email.TabIndex = 24;
            this.email.Text = "Email";
            this.email.Click += new System.EventHandler(this.label1_Click);
            // 
            // s_email
            // 
            this.s_email.Location = new System.Drawing.Point(106, 238);
            this.s_email.Name = "s_email";
            this.s_email.Size = new System.Drawing.Size(141, 20);
            this.s_email.TabIndex = 25;
            this.s_email.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // StudentInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(355, 450);
            this.Controls.Add(this.s_email);
            this.Controls.Add(this.email);
            this.Controls.Add(this.Register);
            this.Controls.Add(this.s_registrationDate);
            this.Controls.Add(this.s_dob);
            this.Controls.Add(this.s_departmentid);
            this.Controls.Add(this.s_contact);
            this.Controls.Add(this.s_address);
            this.Controls.Add(this.s_lname);
            this.Controls.Add(this.s_fname);
            this.Controls.Add(this.s_studentid);
            this.Controls.Add(this.Female);
            this.Controls.Add(this.s_msD);
            this.Controls.Add(this.s_msS);
            this.Controls.Add(this.s_msM);
            this.Controls.Add(this.Male);
            this.Controls.Add(this.sr_date);
            this.Controls.Add(this.s_tel);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.gender);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.last_name);
            this.Controls.Add(this.Marital_status);
            this.Controls.Add(this.first_name);
            this.Controls.Add(this.DepartmentID);
            this.Controls.Add(this.studenrtid);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "StudentInformation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StudentInformation";
            this.Load += new System.EventHandler(this.StudentInformation_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label studenrtid;
        private System.Windows.Forms.Label DepartmentID;
        private System.Windows.Forms.Label first_name;
        private System.Windows.Forms.Label Marital_status;
        private System.Windows.Forms.Label last_name;
        private System.Windows.Forms.Label Date;
        private System.Windows.Forms.Label gender;
        private System.Windows.Forms.Label Address;
        private System.Windows.Forms.Label s_tel;
        private System.Windows.Forms.Label sr_date;
        private System.Windows.Forms.RadioButton Male;
        private System.Windows.Forms.RadioButton s_msM;
        private System.Windows.Forms.RadioButton s_msS;
        private System.Windows.Forms.RadioButton s_msD;
        private System.Windows.Forms.RadioButton Female;
        private System.Windows.Forms.TextBox s_studentid;
        private System.Windows.Forms.TextBox s_fname;
        private System.Windows.Forms.TextBox s_lname;
        private System.Windows.Forms.TextBox s_address;
        private System.Windows.Forms.TextBox s_contact;
        private System.Windows.Forms.TextBox s_departmentid;
        private System.Windows.Forms.DateTimePicker s_dob;
        private System.Windows.Forms.DateTimePicker s_registrationDate;
        private System.Windows.Forms.Button Register;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.TextBox s_email;
    }
}

