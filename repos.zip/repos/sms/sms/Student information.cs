﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace sms
{
    public partial class StudentInformation : Form
    {
        String Gender;
        String Marital_Status;
        public StudentInformation()
        {
            InitializeComponent();

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void StudentInformation_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Register_Click(object sender, EventArgs e)
        {
            //creating connection and saving
            try
            {
                String connectionString = "Data Source = JACKSWANCEE\\SQLEXPRESS; Initial Catalog = Sms; Integrated Security = True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into Student_Information(StudentID,First_Name, Last_Name, Date_Of_Birth,Address,Gender, Email, Telephone, Marital_status, DepartmentID,Date_of_Registration) values ('" + s_studentid.Text + "', '" + s_fname.Text + "','" + s_lname.Text + "', '" + s_dob.Text + "','" + s_address.Text + "','" + s_contact.Text + "','" + Gender + "','" + s_email.Text + "','" + Marital_Status + "','" + s_departmentid.Text + "','" + s_registrationDate.Text + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully saved record for Student_Information" + s_studentid.Text + "Name " + s_fname.Text);
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " + s_studentid.Text + ex.Message);
            }
        }

        private void s_genderM_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "Male";
        }

        private void s_genderF_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "Female";
        }

        private void s_msM_CheckedChanged(object sender, EventArgs e)
        {
            Marital_Status = " Married";
        }

        private void s_msS_CheckedChanged(object sender, EventArgs e)
        {
            Marital_Status = " Single";
        }

        private void s_msD_CheckedChanged(object sender, EventArgs e)
        {
            Marital_Status = " Divorced";
        }
    }
}
