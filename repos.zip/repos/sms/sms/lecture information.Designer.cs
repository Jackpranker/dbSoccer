﻿namespace sms
{
    partial class lecture_information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.l_msD = new System.Windows.Forms.RadioButton();
            this.l_msS = new System.Windows.Forms.RadioButton();
            this.l_msM = new System.Windows.Forms.RadioButton();
            this.l_GenderF = new System.Windows.Forms.RadioButton();
            this.l_GenderM = new System.Windows.Forms.RadioButton();
            this.l_lectureid = new System.Windows.Forms.TextBox();
            this.l_fname = new System.Windows.Forms.TextBox();
            this.l_lname = new System.Windows.Forms.TextBox();
            this.l_contact = new System.Windows.Forms.TextBox();
            this.l_address = new System.Windows.Forms.TextBox();
            this.l_departmentid = new System.Windows.Forms.TextBox();
            this.l_qualification = new System.Windows.Forms.TextBox();
            this.l_dob = new System.Windows.Forms.DateTimePicker();
            this.l_edate = new System.Windows.Forms.DateTimePicker();
            this.l_Register = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "LectureID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 153);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Address";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 259);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Marital_Status";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 291);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Qualification";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 56);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "F_name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(33, 215);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Contact";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 350);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "DepartmentID";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(32, 90);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "L_Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 115);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Date_Of_Birth";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(34, 184);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Gender";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 319);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(99, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Employement_Date";
            // 
            // l_msD
            // 
            this.l_msD.AutoSize = true;
            this.l_msD.Location = new System.Drawing.Point(226, 257);
            this.l_msD.Name = "l_msD";
            this.l_msD.Size = new System.Drawing.Size(68, 17);
            this.l_msD.TabIndex = 11;
            this.l_msD.TabStop = true;
            this.l_msD.Text = "Divorced";
            this.l_msD.UseVisualStyleBackColor = true;
            this.l_msD.CheckedChanged += new System.EventHandler(this.l_msD_CheckedChanged);
            // 
            // l_msS
            // 
            this.l_msS.AutoSize = true;
            this.l_msS.Location = new System.Drawing.Point(100, 255);
            this.l_msS.Name = "l_msS";
            this.l_msS.Size = new System.Drawing.Size(54, 17);
            this.l_msS.TabIndex = 12;
            this.l_msS.TabStop = true;
            this.l_msS.Text = "Single";
            this.l_msS.UseVisualStyleBackColor = true;
            // 
            // l_msM
            // 
            this.l_msM.AutoSize = true;
            this.l_msM.Location = new System.Drawing.Point(160, 257);
            this.l_msM.Name = "l_msM";
            this.l_msM.Size = new System.Drawing.Size(60, 17);
            this.l_msM.TabIndex = 13;
            this.l_msM.TabStop = true;
            this.l_msM.Text = "Married";
            this.l_msM.UseVisualStyleBackColor = true;
            this.l_msM.CheckedChanged += new System.EventHandler(this.l_msM_CheckedChanged);
            // 
            // l_GenderF
            // 
            this.l_GenderF.AutoSize = true;
            this.l_GenderF.Location = new System.Drawing.Point(173, 180);
            this.l_GenderF.Name = "l_GenderF";
            this.l_GenderF.Size = new System.Drawing.Size(59, 17);
            this.l_GenderF.TabIndex = 14;
            this.l_GenderF.TabStop = true;
            this.l_GenderF.Text = "Female";
            this.l_GenderF.UseVisualStyleBackColor = true;
            this.l_GenderF.CheckedChanged += new System.EventHandler(this.l_GenderF_CheckedChanged);
            // 
            // l_GenderM
            // 
            this.l_GenderM.AutoSize = true;
            this.l_GenderM.Location = new System.Drawing.Point(103, 180);
            this.l_GenderM.Name = "l_GenderM";
            this.l_GenderM.Size = new System.Drawing.Size(48, 17);
            this.l_GenderM.TabIndex = 15;
            this.l_GenderM.TabStop = true;
            this.l_GenderM.Text = "Male";
            this.l_GenderM.UseVisualStyleBackColor = true;
            this.l_GenderM.CheckedChanged += new System.EventHandler(this.l_GenderM_CheckedChanged);
            // 
            // l_lectureid
            // 
            this.l_lectureid.Location = new System.Drawing.Point(100, 18);
            this.l_lectureid.Name = "l_lectureid";
            this.l_lectureid.Size = new System.Drawing.Size(100, 20);
            this.l_lectureid.TabIndex = 16;
            // 
            // l_fname
            // 
            this.l_fname.Location = new System.Drawing.Point(100, 53);
            this.l_fname.Name = "l_fname";
            this.l_fname.Size = new System.Drawing.Size(100, 20);
            this.l_fname.TabIndex = 17;
            // 
            // l_lname
            // 
            this.l_lname.Location = new System.Drawing.Point(100, 87);
            this.l_lname.Name = "l_lname";
            this.l_lname.Size = new System.Drawing.Size(100, 20);
            this.l_lname.TabIndex = 18;
            // 
            // l_contact
            // 
            this.l_contact.Location = new System.Drawing.Point(101, 212);
            this.l_contact.Name = "l_contact";
            this.l_contact.Size = new System.Drawing.Size(100, 20);
            this.l_contact.TabIndex = 19;
            // 
            // l_address
            // 
            this.l_address.Location = new System.Drawing.Point(100, 150);
            this.l_address.Name = "l_address";
            this.l_address.Size = new System.Drawing.Size(100, 20);
            this.l_address.TabIndex = 20;
            // 
            // l_departmentid
            // 
            this.l_departmentid.Location = new System.Drawing.Point(100, 350);
            this.l_departmentid.Name = "l_departmentid";
            this.l_departmentid.Size = new System.Drawing.Size(100, 20);
            this.l_departmentid.TabIndex = 21;
            // 
            // l_qualification
            // 
            this.l_qualification.Location = new System.Drawing.Point(100, 284);
            this.l_qualification.Name = "l_qualification";
            this.l_qualification.Size = new System.Drawing.Size(100, 20);
            this.l_qualification.TabIndex = 22;
            // 
            // l_dob
            // 
            this.l_dob.CustomFormat = "yyyy-MM-dd";
            this.l_dob.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.l_dob.Location = new System.Drawing.Point(100, 115);
            this.l_dob.Name = "l_dob";
            this.l_dob.Size = new System.Drawing.Size(101, 20);
            this.l_dob.TabIndex = 23;
            this.l_dob.Value = new System.DateTime(2021, 3, 5, 0, 0, 0, 0);
            // 
            // l_edate
            // 
            this.l_edate.CustomFormat = "yyyy-MM-dd";
            this.l_edate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.l_edate.Location = new System.Drawing.Point(118, 319);
            this.l_edate.Name = "l_edate";
            this.l_edate.Size = new System.Drawing.Size(82, 20);
            this.l_edate.TabIndex = 24;
            // 
            // l_Register
            // 
            this.l_Register.Location = new System.Drawing.Point(118, 395);
            this.l_Register.Name = "l_Register";
            this.l_Register.Size = new System.Drawing.Size(75, 23);
            this.l_Register.TabIndex = 25;
            this.l_Register.Text = "Register";
            this.l_Register.UseVisualStyleBackColor = true;
            this.l_Register.Click += new System.EventHandler(this.button1_Click);
            // 
            // lecture_information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 450);
            this.Controls.Add(this.l_Register);
            this.Controls.Add(this.l_edate);
            this.Controls.Add(this.l_dob);
            this.Controls.Add(this.l_qualification);
            this.Controls.Add(this.l_departmentid);
            this.Controls.Add(this.l_address);
            this.Controls.Add(this.l_contact);
            this.Controls.Add(this.l_lname);
            this.Controls.Add(this.l_fname);
            this.Controls.Add(this.l_lectureid);
            this.Controls.Add(this.l_GenderM);
            this.Controls.Add(this.l_GenderF);
            this.Controls.Add(this.l_msM);
            this.Controls.Add(this.l_msS);
            this.Controls.Add(this.l_msD);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "lecture_information";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "lecture_information";
            this.Load += new System.EventHandler(this.lecture_information_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RadioButton l_msD;
        private System.Windows.Forms.RadioButton l_msS;
        private System.Windows.Forms.RadioButton l_msM;
        private System.Windows.Forms.RadioButton l_GenderF;
        private System.Windows.Forms.RadioButton l_GenderM;
        private System.Windows.Forms.TextBox l_lectureid;
        private System.Windows.Forms.TextBox l_fname;
        private System.Windows.Forms.TextBox l_lname;
        private System.Windows.Forms.TextBox l_contact;
        private System.Windows.Forms.TextBox l_address;
        private System.Windows.Forms.TextBox l_departmentid;
        private System.Windows.Forms.TextBox l_qualification;
        private System.Windows.Forms.DateTimePicker l_dob;
        private System.Windows.Forms.DateTimePicker l_edate;
        private System.Windows.Forms.Button l_Register;
    }
}