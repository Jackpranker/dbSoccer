﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sms
{
    public partial class lecture_information : Form
    {
        string Gender;
        string Marital_Status;
        public lecture_information()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                String connectionString = "Data Source = JACKSWANCEE\\SQLEXPRESS; Initial Catalog = Sms; Integrated Security = True";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into Lecture_Information(LectureID,First_Name, Last_Name, Date_of_Birth,Address,Gender, Contact, Marital_Status, Qualification,Date_of_Employement,DepartmentID) values ('" + l_lectureid.Text + "', '" + l_fname.Text + "','" + l_lname.Text + "', '" + l_dob.Text + "','" + l_address.Text + "','" + Gender + "','" + l_contact.Text + "','" + Marital_Status + "','" + l_qualification.Text + "','" + l_edate.Text + "','" + l_departmentid.Text + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully saved record for Lecture_Information" + l_lectureid.Text + "Name " + l_fname.Text);
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Record cannot be Inserted check it might exist " + l_lectureid.Text + ex.Message);
            }
        }

        private void l_GenderM_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "Male";
        }

        private void l_GenderF_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "Female";
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Marital_Status = "Single";
        }

        private void l_msM_CheckedChanged(object sender, EventArgs e)
        {
            Marital_Status = "Married";
        }

        private void l_msD_CheckedChanged(object sender, EventArgs e)
        {
            Marital_Status = "Divorced";
        }

        private void lecture_information_Load(object sender, EventArgs e)
        {

        }
    }
    }

